# Handoff: Field Notes site redesign

> A complete visual + IA redesign of [`ObliviousWill/field-notes`](https://github.com/ObliviousWill/field-notes), spanning Home, Blog index, Post detail, Projects index, Project detail, and About — desktop and mobile.

## Overview

This handoff specifies a refresh of the Field Notes website that takes the bare Astro blog starter and gives every page the same considered typographic vocabulary. The brand DNA already in the repo (cream / slate / amber palette, Bowlby-style chunky display headings, Atkinson Hyperlegible body) is preserved and pushed harder. New patterns are introduced for content that wasn't designed at all yet (post body typography, project detail with updates timeline) and existing patterns (status pills, link underlines) are reused exactly.

## About the design files

The files in `prototype/` are **design references** built in HTML + React + Babel. They are not production code — they exist so you can open one HTML file (`Site redesign.html`), see all six pages at both desktop (1280px) and mobile (390px), and use that as the source of truth for layout, type, color, spacing and interaction.

**Your job is to recreate these designs inside the existing Astro repo** — keeping its content collections, its routing, its `global.css` tokens and its existing component patterns where they apply. **Do not** ship the React/JSX directly. Astro + scoped styles in `.astro` components is the target environment.

## Fidelity

**High fidelity.** All colors, font sizes, spacings, hover states and micro-interactions are intentional. Match them. Where you find ambiguity, fall back to the JSX source in `prototype/` — it's the canonical reference.

---

## Repo context — what's already there

The Astro project is already partly set up. Before adding anything, know that:

| What | Where | Status |
|---|---|---|
| Color tokens | `src/styles/global.css` (`--bg`, `--text`, `--accent`, etc.) | Keep as-is — the design uses these |
| Status pill CSS | `src/styles/global.css` (`.status`, `.status-building`, `.status-shipped`, `.status-paused`) | Reuse exactly |
| Body font | Atkinson Hyperlegible at `src/assets/fonts/atkinson-*.woff`, loaded as `--font-atkinson` via Astro's font integration | Keep |
| Display font | **Not yet installed.** Add Bowlby One. | New (see Design tokens below) |
| Content collections | `src/content.config.ts` defines `blog`, `projects`, `updates` with the right schemas | Use as-is |
| `tags` enum on blog posts | `'building' \| 'marketing' \| 'ai'` | The category chip design assumes exactly these three |
| `status` enum on projects | `'building' \| 'shipped' \| 'paused'` | Maps to existing `.status-*` pill classes |
| Reading time util | `src/utils/readingTime.ts` | Use for every post page |
| Projects util | `src/utils/projects.ts` | Use to attach updates to projects |
| OG image generation | `src/pages/og/[slug].png.ts` | Keep — works orthogonally to the redesign |

## Design tokens

### Colors — already in `src/styles/global.css`, do not change

| Token | Value | Use |
|---|---|---|
| `--bg` | `#eee9df` | Page background (gradient top + flat bottom) |
| `--bg-tint` | `#e3ddd0` | Code blocks, footer band, faint surfaces |
| `--bg-soft` | `#f5f1e8` | Cards, hover row tint, inputs, gradient top |
| `--text` | `44, 59, 77` (rgb tuple) | Body ink |
| `--text-muted` | `79, 93, 111` | Secondary text |
| `--accent` | `#ffb162` | Accent fills, underlines, "Latest" markers, building pill |
| `--accent-ink` | `#8a4509` | Link text (passes contrast against cream) |

Derived values used by the design:

```css
--hairline:      rgba(44, 59, 77, 0.15);   /* dividers */
--hairline-soft: rgba(44, 59, 77, 0.08);   /* row separators inside lists */
--muted-soft:    rgba(44, 59, 77, 0.55);   /* fine print */
```

### Category accent palette (color-coded chip variant)

Used when category color-coding is on. All three live at the same OKLCH chroma/lightness as the accent — only the hue rotates.

| Tag | Solid | Soft fill (chip bg) | Ink (chip text) |
|---|---|---|---|
| `ai` | `#ffb162` | `rgba(255, 177, 98, 0.22)` | `#8a4509` |
| `building` | `#9ccaa6` | `rgba(156, 202, 166, 0.32)` | `#23533a` |
| `marketing` | `#d7aedb` | `rgba(215, 174, 219, 0.30)` | `#5e2a64` |

Provide a CSS toggle (data-attr or class) so chips can fall back to a neutral grey if the user prefers — see "Tweaks" at the bottom.

### Typography

| Family | Loading | Use | Notes |
|---|---|---|---|
| **Bowlby One** | Add via Astro `fontProviders.google()` or another Google Fonts integration. CSS variable `--font-display`. Fallback chain: `'Bowlby One', 'Alfa Slab One', Georgia, serif` | All h1–h4, brand wordmark, project/blog titles | Chunky slab. Only 400 weight exists — that's fine. |
| **Atkinson Hyperlegible** | Already loaded — `--font-atkinson` | All body text, meta, chips, buttons, nav | 400 / 700 |

Type scale (the rendered sizes you'll see in the prototype — match these):

| Role | Desktop | Mobile |
|---|---|---|
| Home / About hero h1 | 88–92px | 56px |
| Page h1 (Blog, Projects) | 64px | 44px |
| Post detail h1 | 56px | 36px |
| Project detail h1 | 60px | 40px |
| Featured/section h2 (blog row latest, post body) | 30–36px | 24–28px |
| Standard post row h2 | 28px | 22px |
| Compact post row h2 (Home recent) | 22px | 20px |
| Body prose | 19px / 1.65 | 17px / 1.65 |
| Italic dek | 22px | 19px |
| Meta / chips / nav | 11–17px | 11–17px |

### Spacing

The site is built on simple multiples. No formal scale — just be consistent.

- Page horizontal padding: `40px` desktop / `20px` mobile
- Page top padding: `56–64px` desktop / `32px` mobile
- Page bottom padding: `72–80px` desktop / `48px` mobile
- Main content max-width: **720px** for prose/blog/post/home, **760px** for projects, **820px** for ledger-style if used
- Row padding: `26–32px` cozy / `18–22px` compact, top + bottom
- Card padding: `20px` mobile / `28px` desktop

### Borders, radius, motion

- Hairlines: `1px solid var(--hairline)` for page dividers, `1px solid var(--hairline-soft)` for row separators inside lists, `1px dashed var(--hairline-soft)` for "draft" / "newsletter inline" surfaces
- Card border radius: `8px`
- Pill (status, chip) radius: `999px`
- Hover-row tint radius: `6px`
- Standard transitions: `200ms ease` for color/opacity; `220–280ms cubic-bezier(.6, 0, .2, 1)` for transform / background-size
- Reading-progress bar: `3px` tall, `var(--accent)` fill, top of post pages, below header

---

## IA / page inventory

Six pages, in your existing Astro routing convention. Map each prototype page to a `.astro` file:

| Prototype page | Astro route | Source layout |
|---|---|---|
| Home | `src/pages/index.astro` | Reuses a global `<Layout>` |
| Blog index | `src/pages/blog/index.astro` | Same layout |
| Post detail | `src/pages/blog/[...slug].astro` | Uses post layout |
| Projects index | `src/pages/projects/index.astro` | Same layout |
| Project detail | `src/pages/projects/[...slug].astro` | Uses project layout |
| About | `src/pages/about.astro` | Same layout |

Plus: a `404.astro` is out of scope for this handoff.

---

## Shared components — build these first

These are reused across multiple pages. Get them right and the pages fall out trivially. Put them in `src/components/`. Each one's source is in `prototype/site-atoms.jsx` and `prototype/blog-variations.jsx`; translate the JSX/inline styles to `.astro` files with scoped `<style>` blocks (or a single shared stylesheet — your call).

### `SiteHeader.astro`

**Props:** `current: 'home' | 'blog' | 'projects' | 'about'`

Layout: flex row, space-between. Left: `FIELD NOTES` wordmark in Bowlby One, color `var(--accent)`, 20px desktop / 18px mobile, links home. Centre: four nav links (`Home`, `Blog`, `Projects`, `About`), gap 36px, 17px, Atkinson. The link matching `current` is `font-weight: 700` AND has a `border-bottom: 2px solid var(--accent)` (the bar sits 2px below the text baseline — see prototype). Right: LinkedIn icon square, 22×22, `#4b5b73` bg, cream "in" glyph.

Mobile (<720px): hide the nav, swap the LinkedIn icon for a `≡` menu glyph at 26×26. Don't build a working mobile menu in this pass — the existing site has a burger menu working, keep it.

Background `var(--bg-soft)`, `border-bottom: 1px solid var(--hairline)`, padding `18px 40px` desktop / `14px 20px` mobile.

### `SiteFooter.astro`

Centred, `var(--bg-tint)` band with a top hairline. Padding `40px 40px 48px` desktop / `28px 20px 36px` mobile. Inside: `© 2026 Will. All rights reserved.` in `var(--text-muted)` 15px, then the LinkedIn icon centred under it.

### `CategoryChip.astro`

**Props:** `tag: 'ai' | 'building' | 'marketing'`; `size?: 'sm' | 'lg'` (default `sm`); `colored?: boolean` (default true).

Uppercase label, letter-spacing `0.10em`, font-weight 700, font-size 10px (sm) / 11px (lg), padding `3px 8px` (sm) / `4px 10px` (lg), `border-radius: 999px`. Background + color come from the category palette table (above) when `colored`, neutral `rgba(44,59,77,0.08)` bg + `var(--text)` ink when not.

### `StatusPill.astro`

**Props:** `status: 'building' | 'shipped' | 'paused'`.

Lift the existing `.status` / `.status-*` CSS from `global.css` verbatim. The design uses these exact classes.

### `UnreadDot.astro` (interactive — needs a `<script>` or Astro island)

A small button that renders a filled `var(--accent)` 8px circle when the post is unread, an empty 1.5px-stroked circle when read. Click toggles state. Persist to `localStorage` under key `fn:read-posts` (a JSON array of post slugs). All six pages read from this same key.

```ts
// Suggested helper in src/utils/readState.ts
export const READ_KEY = 'fn:read-posts';
export function getRead(): string[] { /* localStorage parse */ }
export function isRead(slug: string): boolean { /* */ }
export function toggleRead(slug: string): void { /* */ }
```

Astro-flavoured: make `UnreadDot.astro` render the SSR markup with `data-slug={slug}` and `data-unread="true"`, then ship one small client script that finds all `[data-unread]`, reads localStorage, flips the state, and wires clicks. Keep the JS to one tiny file.

### `FNLink.astro`

A text link with the underline-wipe hover effect that already exists in `global.css` (`.prose a`, `p a`, `.section-heading a` — the background-image gradient trick). Pull that pattern out into a generic class — e.g. `.fn-link` — so it can be applied anywhere, not only inside paragraphs and section headings.

### `PostRow.astro` — the most-used atom

Used on Home (compact), Blog index (standard), Post detail "Next note" (compact), Project detail "Related posts" (compact).

**Props:** `post: CollectionEntry<'blog'>`; `compact?: boolean`; `showExcerpt?: boolean = true`; `colored?: boolean = true`.

Structure (top-down):
1. **Meta line.** Horizontal flex, gap 10px, font 13px, color `var(--text-muted)`. Order:
   - `<CategoryChip>` per tag (multiple chips, gap 10px)
   - middot separator (`<span style="opacity:0.4">·</span>`)
   - Formatted date (e.g. `20 May 2026`)
   - middot
   - `{readTime} min read`
   - **If `updatedDate` is set:** middot, then `↻ updated` in `var(--accent-ink)` 12px
2. **Title.** `var(--font-display)`, 28px standard / 22px compact, line-height 1.12, color `var(--text)`. On hover, an animated wipe: a 6px-tall `var(--accent)` bar grows from 0 → 100% width behind the text (use the `background-image: linear-gradient(...)` + `background-size` trick from `global.css`). Transition `280ms cubic-bezier(.6,0,.2,1)`.
3. **Excerpt.** Description, 17px standard / 16px mobile, line-height 1.55, `var(--text-muted)`, max-width 620px.
4. **Mentions row (if any).** "MENTIONS" kicker (11px uppercase muted) followed by `FNLink`-styled project names, each prefixed with `↗`.

Hover: a `var(--bg-soft)` slab at `opacity: 0.7` slides in behind the whole row, bleeding 24px outside the content edge on desktop / 12px on mobile, border-radius 6px. The `UnreadDot` sits in a 24px column to the left of the row content; the dot stays in place — only the slab and the title underline animate.

Row separators: `border-top: 1px solid var(--hairline-soft)` on every row.

Click on the title navigates to the post; click on the dot toggles read state. Whole-row click is reserved for navigation.

### `ProjectCard.astro`

Used on Home (single, building only) and Projects index (all, in groups).

**Props:** `project: CollectionEntry<'projects'>`; `expanded?: boolean = false`.

Structure:
- Outer card: `var(--bg-soft)` background, `1px solid var(--hairline-soft)` border, `border-radius: 8px`, padding `28px` desktop / `20px` mobile. On hover, border color → `rgba(255, 177, 98, 0.7)` (transition 200ms).
- Header row: "PROJECT" kicker (11px uppercase muted) on the left, `<StatusPill>` on the right.
- Title (`<a>`): 30px desktop / 24px mobile, `var(--font-display)`, color `var(--text)`. Same hover-wipe underline as `PostRow` titles.
- Summary paragraph: 17px, `var(--text-muted)`, line-height 1.55.
- Footer strip (top border `1px dashed var(--hairline-soft)`, padding-top 14px): "LATEST" kicker, the latest update's title as an `FNLink`, middot, formatted date. When `expanded`, push to the right edge: `{count} update(s)` in muted uppercase.

### `NewsletterBlock.astro`

Used at the bottom of: Home, Blog, Post, Project detail.

Top hairline rule. Big "Get these in your inbox." headline in `var(--font-display)` (34px desktop / 28px mobile). One line of muted explainer ("Roughly weekly. No schedule, no spam — just a heads-up when a new note goes up."). Then an inline form: email input (cream-tinted, 4px radius, hairline border) + a `var(--text)`-filled "Subscribe →" button. To the right of the button (or wrapping below on mobile): "or grab the [RSS feed ↗]" in muted 14px, where "RSS feed ↗" uses `FNLink`.

The form should `POST` somewhere real eventually — for now leave it as a placeholder action / mailto.

### `PageTitle.astro`

**Props:** `title: string`; `count?: number`; `countLabel?: string`; `subtitle?: string`; `sideLink?: slot`.

Used on Blog, Projects, About. Big h1 (64/44) on the left; on the right, baseline-aligned: `{count} {countLabel}` in 13px uppercase muted, middot, then a slot for an RSS link. Below: subtitle paragraph at 19/17, muted, max-width 620px.

---

## Page-by-page spec

### 1. Home — `src/pages/index.astro`

**Source:** `prototype/page-home.jsx` · render with the Home artboards in `Site redesign.html`.

Sections in order:
1. **Hero.** "A WORKING NOTEBOOK" tiny kicker, then a 92px (56 mobile) `Field Notes` h1. Below: the existing tagline ("Notes from the field on marketing, building, and AI in practice — written in the open by someone doing the work, not watching it.") at 22px/18 muted, max-width 580px. Then a row: "New posts roughly weekly." + an `FNLink` "More about this site →".
2. Hairline rule.
3. **Currently building** section. Section heading "Currently building" (30/24 display) with an `FNLink` "All projects →" baseline-right. Below: a single `ProjectCard` for the most-recent `status === 'building'` project (currently Field Notes (this site)).
4. **Recent posts** section. Heading "Recent posts" + "All posts →" link. List of the top 3 posts as `PostRow compact`.
5. `NewsletterBlock`.

Content max-width 720px.

### 2. Blog index — `src/pages/blog/index.astro`

**Source:** `prototype/page-blog.jsx`.

`PageTitle` with `title="Blog"`, `count={posts.length}`, `countLabel="posts"`, `subtitle="What I'm working through, in the open. Newest first."`, `sideLink={RSS}`.

Below the title, a small legend line: an unread dot, the text `= unread · {n} of {total}`, and a right-aligned "mark all unread" link that empties `localStorage['fn:read-posts']`.

Hairline rule.

Posts as a `<ol>` of `PostRow` (standard, not compact). Order: reverse-chron by `pubDate`.

`NewsletterBlock` at the bottom.

### 3. Post detail — `src/pages/blog/[...slug].astro`

**Source:** `prototype/page-post.jsx`. The most carefully designed page.

Structure (top to bottom):
1. `SiteHeader` (current="blog")
2. **Reading-progress bar.** A 3px-tall `var(--accent)` fill on top of `var(--hairline-soft)`. Width updates on `scroll` based on `window.scrollY / (document.documentElement.scrollHeight - innerHeight)`. Persist `position` is NOT needed; this is purely visual.
3. **Breadcrumb strip.** Left: `← All notes` link. Right: `· ~N min left of {readTime}` with a small accent dot — same `scroll` listener can drive this.
4. **Header.**
   - Category chips row (size `lg`).
   - h1: 56px desktop / 36px mobile, `text-wrap: pretty`.
   - Italic dek (the post's `description` from frontmatter): 22/19 muted, max-width 620px.
   - Byline rule: `border-top: 1px solid var(--hairline-soft)` above a row containing **Will** (bold, ink), middot, formatted `pubDate`, middot, `{readTime} min read`. If `updatedDate`, add middot + `↻ updated {date}` in `var(--accent-ink)`.
5. **Body / `.prose`.** Render the post markdown. The body typography from the existing `global.css` is mostly right; the changes the design makes are:
   - Blockquotes: 4px solid `var(--accent)` left border, 26/21 in `var(--font-display)`, regular weight (not bold). Margin top/bottom generous (40px/32px).
   - Inline code: kept as-is.
   - **Mono "blockquote-as-code-input"** treatment (e.g. when showing a verbatim search-box prompt): use a `var(--bg-tint)` background, 6px radius, 18×22px padding, monospace family at 16px. This is a `<pre>` or a wrapped `<p>` with a specific class — see the prototype for the "Write a follow-up email…" line.
   - h2 inside body: `var(--font-display)`, 36/28, margin top 56/40, bottom 22/18, letter-spacing `-0.01em`.
   - h3 / h4 / paragraphs: as `global.css` defines.
   - Lists (`<ol>`, `<ul>`): 22px left padding, 14px between items.
6. **Mentions aside.** Below the body, a two-column block (180px label + flexible content on desktop, stacked on mobile). Label: "MENTIONS" in display 20/18 uppercase. Each mentioned project: a soft-tinted row with the project's `StatusPill`, an `FNLink` to the project, and a right-aligned "PROJECT ↗" caption.
7. **Next note.** "NEXT NOTE" kicker, then a single `PostRow compact` for the next post in reverse-chron order.
8. `NewsletterBlock`.
9. `SiteFooter`.

Content max-width 720px.

### 4. Projects index — `src/pages/projects/index.astro`

**Source:** `prototype/page-projects.jsx`.

`PageTitle title="Projects"` with project count + RSS side link + subtitle: "What I'm building, with the work shown — decisions, dead ends, screenshots, and what I'd do differently. Each project has its own page with a running log of updates."

Status legend strip below the title: three inline status pills, each followed by a label ("active" / "on hold" / "done").

Hairline rule.

Then up to three `ProjectGroup` sections, conditional on whether there's anything in them:
- **Active** (status === 'building')
- **On hold** (status === 'paused')
- **Shipped** (status === 'shipped')

Each `ProjectGroup`:
- A heading row: section title in display 22/20, a flex-fill hairline, a count at the right in 11px uppercase muted.
- A vertical stack of `ProjectCard expanded` (gap 18 desktop / 14 mobile).

At the bottom, a cross-link card pointing back to the blog (see the prototype's bottom block: dashed-border card, headline + body + "Go to the blog →" link). This is one of the few places where the design does add new copy; keep the copy as-written.

Content max-width 760px.

### 5. Project detail — `src/pages/projects/[...slug].astro`

**Source:** `prototype/page-project.jsx`.

Structure:
1. Breadcrumb strip: `← All projects` left, `↗ GitHub repo` right (sourced from `project.data.links[0]`).
2. **Header.** Status pill + "Started {formatted date}" in a row. h1 (60/40 display). Italic summary (`project.data.summary`) 21/18 muted.
3. **Quick-facts strip.** A `var(--bg-soft)` card, 8px radius, hairline border, padding 18×22. Four-column grid on desktop (one column on mobile). Each cell has an 11px uppercase muted label and a 15px ink value. Source the facts from the project body (or from a new `facts` schema field if you want to make it real). For the Field Notes project: Tech / Status / Hosting / Cost.
4. **Description paragraph.** The project's body intro (the prose under the frontmatter in the markdown). 19px / 1.65, max-width 680.
5. **Updates timeline.** Section heading "Updates" with a right-aligned `{n} entry/entries` count.
6. Each update rendered as an `UpdateEntry`:
   - Two-column grid: a 100px (70px mobile) right-aligned date gutter on the left, content on the right, with a vertical timeline line (2px wide, `var(--hairline-soft)`) and a 10px dot sitting on it. The first/most-recent update's dot is filled `var(--accent)`; older dots are unfilled.
   - Date gutter shows `{DAY} {MON}` in 13px uppercase + year underneath in mutedSoft 11px.
   - Content: h3 title (28/22 display), body paragraphs (17/16 normal prose), then any subsections — each with its own h4 (display 19/17) followed by a custom list of `{strong label}. {body}` items, each prefixed with a 6×6px `var(--accent)` square bullet.
7. **Related posts.** Reverse-chron list of `PostRow compact` for any post whose body mentions this project (use the existing utility or a frontmatter relation). Skip the section if empty.
8. `NewsletterBlock`.

Content max-width 760px.

### 6. About — `src/pages/about.astro`

**Source:** `prototype/page-about.jsx`.

Structure:
1. **Hero.** Big "About" h1 (88/56 display). Below: a byline rule — **Will** (bold), middot, "Head of Marketing & CX", middot, "UK". Bottom hairline on the byline row.
2. Italic dek (22/19 muted): the existing About-page dek copy.
3. **Intro paragraphs.** Three paragraphs at 19/17.
4. **"What you'll find here" section.** Display h2 36/28. Lead-in paragraph. Then three `AboutCategoryBlock`s, one per category. Each block is a two-column grid (180px label + flexible content): left column shows the `CategoryChip` (size `lg`) and a small "Browse →" `FNLink`; right column has a display 22/20 title and a muted body paragraph at 17/16. Separator: `border-top: 1px solid var(--hairline-soft)` on each block.
5. **"Who I'm writing for"** + **"A note on what this isn't"** sections. Each is a display h2 plus one body paragraph.
6. `NewsletterBlock`.

Content max-width 720px.

---

## Interaction & motion details

| Trigger | Effect |
|---|---|
| Hover a `PostRow` | (1) `var(--bg-soft)` slab opacity 0 → 0.7 in 200ms, bleeding 24px (12 on mobile) outside the row. (2) Title gets a 6px `var(--accent)` underline that wipes left → right in 280ms `cubic-bezier(.6, 0, .2, 1)`. |
| Hover a `ProjectCard` | Border color → `rgba(255, 177, 98, 0.7)` in 200ms. Title gets the same underline wipe as `PostRow`. |
| Click `UnreadDot` | Toggle slug membership in `localStorage['fn:read-posts']`; dot transitions filled ↔ outlined in 200ms. Don't navigate. |
| Click `PostRow` title | Navigate to the post (don't toggle read state on title click). |
| Scroll a post page | The 3px progress bar's width updates live based on `scrollY / (scrollHeight - innerHeight)`. The "~N min left" caption uses the same fraction × `readTime` and rounds. |
| Hover any `FNLink` | The background-size goes from `100% 2px` to `100% 100%` in 200ms — i.e. the highlight rises to engulf the link. This is the existing pattern in `global.css`. |
| Animated "Latest" dot (if you use it) | 2.2s ease-in-out infinite pulse: opacity 1 → 0.6, scale 1 → 1.4 and back. (Used in the prototype's ledger/sheet variants — optional for V1.) |

Respect `prefers-reduced-motion: reduce` for all of the above — the existing `global.css` already turns off scroll-behavior under it; extend that to the row underline and slab tint.

## Responsive

One breakpoint: **720px**. Above: desktop layout (nav visible, two-column grids, 40px page padding). Below: mobile layout (hamburger, single-column grids, 20px page padding, type one step down per the table above). The `global.css` already establishes this breakpoint — keep it.

## Read-state persistence

Already specified above. One key: `fn:read-posts`. One array of slugs. One small client script shipped on every page so the unread dots reflect reality wherever they appear (Home recent posts, Blog index, Post detail "Next note", Project detail "Related posts").

## RSS / subscribe

The "Subscribe →" button has no real destination yet. Leave it as a placeholder (a `<form action="#">` or a `mailto:`). The RSS link points to the existing `src/pages/rss.xml.js`-generated feed. Don't ship a fake newsletter integration.

## Tweaks (not shipping to prod — for design exploration only)

The prototype includes a Tweaks panel with three knobs:
- **Density:** cozy (default) vs compact — affects row padding on `PostRow`.
- **Show excerpts:** toggles the description paragraph on `PostRow`.
- **Color-coded categories:** toggles the per-tag chip palette vs neutral grey.

You **do not need** to ship the Tweaks panel into production. But all three settings are decisions worth making explicit. Default values: cozy / excerpts on / colored on.

## What I did not change

- The existing OG image generation at `src/pages/og/[slug].png.ts` — keep it.
- The existing RSS feeds at `src/pages/rss.xml.js` and `src/pages/projects/rss.xml.js`.
- The content schemas in `src/content.config.ts` — they already cover everything the design needs.
- The mobile burger menu — keep the existing implementation; the redesign doesn't touch the open-menu state.

---

## Files in this bundle

```
prototype/
├── Site redesign.html        ← open this in a browser to see all six pages
├── design-canvas.jsx          ← canvas wrapper (not part of the spec — viewer chrome only)
├── tweaks-panel.jsx           ← tweaks UI (not part of the spec)
├── blog-variations.jsx        ← shared TOKENS, POSTS, CAT, atoms (CategoryChip, UnreadDot, FNLink, fmtDate, useUnreadState)
├── site-atoms.jsx             ← shared site chrome + PostRow + ProjectCard + NewsletterBlock + PROJECTS
├── page-home.jsx              ← Home page
├── page-blog.jsx              ← Blog index
├── page-post.jsx              ← Post detail (with embedded sample body)
├── page-projects.jsx          ← Projects index
├── page-project.jsx           ← Project detail (with updates timeline)
├── page-about.jsx             ← About page
└── site-app.jsx               ← canvas host (not part of the spec)
```

When in doubt: open `Site redesign.html`, focus the artboard you're working from, inspect the DOM. Everything you need is in there.

## Recommended implementation order

1. **Tokens** — add Bowlby One font, confirm category palette in `global.css`.
2. **`SiteHeader`** + **`SiteFooter`** + **`FNLink`** class → drop into a global `Layout.astro`.
3. **`CategoryChip`** + **`StatusPill`** + **`UnreadDot`** (with the localStorage helper).
4. **`PostRow`** — Blog index can now be built end-to-end.
5. **`ProjectCard`** — Home and Projects index can now be built.
6. **`PageTitle`** + **`SectionHeading`** + **`NewsletterBlock`** — finish Home, Blog, Projects, About.
7. **Post detail** — bring the body type up to spec, add the reading progress bar, build the Mentions aside.
8. **Project detail** — build `UpdateEntry` last; it's the heaviest custom component.
9. Manual QA pass on mobile.

Good luck.
