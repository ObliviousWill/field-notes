// blog-variations.jsx — three responsive blog-page redesigns for Field Notes.
// Three artboards per variation: desktop (1280) + mobile (390).

// ────────────────────────────────────────────────────────────
// Shared data — 2 real posts + 3 plausible upcoming
// ────────────────────────────────────────────────────────────

const POSTS = [
  {
    slug: 'how-to-get-the-most-out-of-your-ai',
    title: 'How to get the most out of your AI — lessons from my time with Claude',
    description: 'Three modes — setup, direction, building — that decide whether you get brilliant work or mediocre work out of any AI tool.',
    date: '2026-05-20',
    readTime: 9,
    tags: ['ai', 'marketing'],
    real: true,
  },
  {
    slug: 'what-i-learned-building-a-website-with-ai',
    title: 'What I learned building a website with AI',
    description: 'One hour, a blank repo, and Claude Code as the only collaborator. What looking under the bonnet revealed about AI, marketing, and the work.',
    date: '2026-05-20',
    updatedDate: '2026-05-21',
    readTime: 5,
    tags: ['building', 'ai'],
    mentions: [{ slug: 'field-notes', label: 'Field Notes (this site)' }],
    real: true,
  },
  {
    slug: 'retention-acquisition-handoff',
    title: 'The retention / acquisition handoff nobody owns',
    description: 'A field note on the seam in the middle of the funnel — where the metrics stop tracking and the work goes wrong.',
    date: '2026-05-12',
    readTime: 7,
    tags: ['marketing'],
  },
  {
    slug: 'meal-planning-app-claude-api',
    title: 'A meal-planning app on the Claude API',
    description: "What I'd do differently the second time. Notes on tools, prompts, and the gap between \"demo\" and \"useful on a Tuesday.\"",
    date: '2026-05-05',
    readTime: 6,
    tags: ['building', 'ai'],
    mentions: [{ slug: 'meal-planner', label: 'Meal planner' }],
  },
  {
    slug: 'team-of-seven-ai-fluency',
    title: 'A team of seven and the case for AI fluency',
    description: "How I'm thinking about getting a small marketing team good — not just users — at the tools they already touch.",
    date: '2026-04-28',
    readTime: 6,
    tags: ['marketing', 'ai'],
  },
];

// ────────────────────────────────────────────────────────────
// Tokens — pulled straight from src/styles/global.css in the repo
// ────────────────────────────────────────────────────────────

const TOKENS = {
  bg: '#eee9df',
  bgTint: '#e3ddd0',
  bgSoft: '#f5f1e8',
  ink: 'rgb(44, 59, 77)',
  inkRGB: '44, 59, 77',
  muted: 'rgb(79, 93, 111)',
  mutedSoft: 'rgba(44, 59, 77, 0.55)',
  hairline: 'rgba(44, 59, 77, 0.15)',
  hairlineSoft: 'rgba(44, 59, 77, 0.08)',
  accent: '#ffb162',
  accentInk: '#8a4509',
};

// Category colors — accent is the base; building/marketing are
// hue-shifted at matched chroma/lightness (oklch) so they stay
// in the same family.
const CAT = {
  ai: { label: 'AI', solid: '#ffb162', soft: 'rgba(255, 177, 98, 0.22)', ink: '#8a4509' },
  building: { label: 'Building', solid: '#9ccaa6', soft: 'rgba(156, 202, 166, 0.32)', ink: '#23533a' },
  marketing: { label: 'Marketing', solid: '#d7aedb', soft: 'rgba(215, 174, 219, 0.30)', ink: '#5e2a64' },
};

const CAT_NEUTRAL = {
  ai: { label: 'AI', soft: 'rgba(44, 59, 77, 0.08)', ink: 'rgb(44, 59, 77)' },
  building: { label: 'Building', soft: 'rgba(44, 59, 77, 0.08)', ink: 'rgb(44, 59, 77)' },
  marketing: { label: 'Marketing', soft: 'rgba(44, 59, 77, 0.08)', ink: 'rgb(44, 59, 77)' },
};

// ────────────────────────────────────────────────────────────
// Hooks: unread state (persisted to localStorage)
// ────────────────────────────────────────────────────────────

function useUnreadState() {
  const KEY = 'fn:read-posts';
  const [read, setRead] = React.useState(() => {
    try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; }
  });
  React.useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(read)); } catch {}
  }, [read]);
  const toggle = (slug) => setRead((r) => r.includes(slug) ? r.filter((s) => s !== slug) : [...r, slug]);
  const isRead = (slug) => read.includes(slug);
  const reset = () => setRead([]);
  return { isRead, toggle, reset };
}

// ────────────────────────────────────────────────────────────
// Format helpers
// ────────────────────────────────────────────────────────────

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function fmtDate(iso) {
  const d = new Date(iso + 'T12:00:00');
  return `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}
function fmtShortDate(iso) {
  const d = new Date(iso + 'T12:00:00');
  return { day: String(d.getDate()).padStart(2, '0'), mon: MONTHS[d.getMonth()].toUpperCase(), year: d.getFullYear() };
}

// ────────────────────────────────────────────────────────────
// Shared atoms
// ────────────────────────────────────────────────────────────

function CategoryChip({ tag, colored = true, size = 'sm' }) {
  const palette = colored ? CAT[tag] : CAT_NEUTRAL[tag];
  const fs = size === 'lg' ? 11 : 10;
  return (
    <span style={{
      display: 'inline-block',
      padding: size === 'lg' ? '4px 10px' : '3px 8px',
      borderRadius: 999,
      fontSize: fs,
      fontWeight: 700,
      letterSpacing: '0.10em',
      textTransform: 'uppercase',
      background: palette.soft,
      color: palette.ink,
      fontFamily: 'var(--font-atkinson)',
      whiteSpace: 'nowrap',
    }}>{palette.label}</span>
  );
}

function UnreadDot({ unread, onClick, size = 8 }) {
  return (
    <button
      type="button"
      onClick={(e) => { e.stopPropagation(); onClick && onClick(); }}
      aria-label={unread ? 'Mark as read' : 'Mark as unread'}
      title={unread ? 'Unread — click to mark read' : 'Read — click to mark unread'}
      style={{
        appearance: 'none',
        border: 'none',
        cursor: 'pointer',
        background: 'transparent',
        padding: 0,
        width: size + 8,
        height: size + 8,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
      }}
    >
      <span style={{
        width: size,
        height: size,
        borderRadius: '50%',
        background: unread ? TOKENS.accent : 'transparent',
        boxShadow: unread ? `0 0 0 1px ${TOKENS.accent}` : `inset 0 0 0 1.5px ${TOKENS.hairline}`,
        transition: 'all 200ms ease',
      }} />
    </button>
  );
}

// Animated text link — replicates the existing site's underline-wipe effect.
function FNLink({ children, href = '#', strong = false, style = {} }) {
  const [h, setH] = React.useState(false);
  return (
    <a href={href}
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      onClick={(e) => e.preventDefault()}
      style={{
        color: TOKENS.accentInk,
        textDecoration: 'none',
        backgroundImage: `linear-gradient(${TOKENS.accent}, ${TOKENS.accent})`,
        backgroundPosition: '0 100%',
        backgroundRepeat: 'no-repeat',
        backgroundSize: h ? '100% 100%' : '100% 2px',
        transition: 'background-size 200ms ease',
        paddingBottom: 1,
        fontWeight: strong ? 700 : 400,
        ...style,
      }}>{children}</a>
  );
}

// ────────────────────────────────────────────────────────────
// Top chrome — recreated from the screenshots (header + footer).
// Kept exactly faithful so the redesigns sit inside the real frame.
// ────────────────────────────────────────────────────────────

function SiteHeader({ mobile = false }) {
  const linkBase = {
    color: TOKENS.ink,
    textDecoration: 'none',
    fontSize: 17,
    fontFamily: 'var(--font-atkinson)',
    padding: '6px 2px',
    position: 'relative',
  };
  return (
    <header style={{
      borderBottom: `1px solid ${TOKENS.hairline}`,
      padding: mobile ? '14px 20px' : '18px 40px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      background: TOKENS.bgSoft,
    }}>
      <div style={{
        fontFamily: 'var(--font-display)',
        color: TOKENS.accent,
        fontSize: mobile ? 18 : 20,
        letterSpacing: '0.02em',
        lineHeight: 1,
      }}>FIELD NOTES</div>
      {!mobile && (
        <nav style={{ display: 'flex', gap: 36 }}>
          <a href="#" onClick={(e) => e.preventDefault()} style={linkBase}>Home</a>
          <a href="#" onClick={(e) => e.preventDefault()} style={{ ...linkBase, fontWeight: 700, borderBottom: `2px solid ${TOKENS.accent}` }}>Blog</a>
          <a href="#" onClick={(e) => e.preventDefault()} style={linkBase}>Projects</a>
          <a href="#" onClick={(e) => e.preventDefault()} style={linkBase}>About</a>
        </nav>
      )}
      <div style={{
        width: mobile ? 24 : 22,
        height: mobile ? 24 : 22,
        background: '#4b5b73',
        color: TOKENS.bgSoft,
        fontSize: 11,
        fontWeight: 700,
        fontFamily: 'var(--font-atkinson)',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 3,
        cursor: 'pointer',
      }}>{mobile ? '≡' : 'in'}</div>
    </header>
  );
}

function SiteFooter() {
  return (
    <footer style={{
      padding: '32px 20px 40px',
      textAlign: 'center',
      color: TOKENS.muted,
      fontSize: 15,
      fontFamily: 'var(--font-atkinson)',
      background: TOKENS.bgTint,
    }}>
      <div style={{ marginBottom: 12 }}>© 2026 Will. All rights reserved.</div>
      <div style={{
        width: 22, height: 22, background: '#4b5b73', color: TOKENS.bgSoft,
        fontSize: 11, fontWeight: 700, borderRadius: 3,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      }}>in</div>
    </footer>
  );
}

// ────────────────────────────────────────────────────────────
// Newsletter / RSS block — three visual treatments, one per variant
// ────────────────────────────────────────────────────────────

function NewsletterIndex({ mobile }) {
  return (
    <section style={{
      marginTop: mobile ? 36 : 56,
      paddingTop: mobile ? 28 : 36,
      borderTop: `1px solid ${TOKENS.hairline}`,
    }}>
      <div style={{
        fontFamily: 'var(--font-display)',
        fontSize: mobile ? 28 : 32,
        color: TOKENS.ink,
        marginBottom: 8,
        lineHeight: 1.1,
      }}>Get these in your inbox.</div>
      <p style={{ color: TOKENS.muted, fontSize: mobile ? 16 : 17, margin: '0 0 18px', maxWidth: 480 }}>
        Roughly weekly. No schedule, no spam — just a heads-up when a new note goes up.
      </p>
      <form onSubmit={(e) => e.preventDefault()} style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
        <input type="email" placeholder="you@email.com" style={{
          flex: '1 1 220px',
          minWidth: 200,
          padding: '12px 14px',
          border: `1px solid ${TOKENS.hairline}`,
          background: TOKENS.bgSoft,
          color: TOKENS.ink,
          fontSize: 16,
          borderRadius: 4,
          fontFamily: 'var(--font-atkinson)',
          outline: 'none',
        }} />
        <button type="submit" style={{
          padding: '12px 18px',
          background: TOKENS.ink,
          color: TOKENS.bgSoft,
          border: 'none',
          fontSize: 15,
          fontWeight: 700,
          borderRadius: 4,
          cursor: 'pointer',
          fontFamily: 'var(--font-atkinson)',
        }}>Subscribe →</button>
        <a href="#" onClick={(e) => e.preventDefault()} style={{
          color: TOKENS.muted, fontSize: 14, textDecoration: 'none',
          marginLeft: mobile ? 0 : 8, fontFamily: 'var(--font-atkinson)',
        }}>or grab the <span style={{ color: TOKENS.accentInk, textDecoration: 'underline', textDecorationColor: TOKENS.accent, textDecorationThickness: 2 }}>RSS feed ↗</span></a>
      </form>
    </section>
  );
}

function NewsletterLedger({ mobile }) {
  return (
    <section style={{
      marginTop: mobile ? 32 : 48,
      padding: mobile ? '24px 0 0' : '32px 0 0',
      borderTop: `1px solid ${TOKENS.hairline}`,
      display: 'grid',
      gridTemplateColumns: mobile ? '1fr' : '140px 1fr',
      gap: mobile ? 12 : 0,
    }}>
      <div style={{
        fontFamily: 'var(--font-display)',
        fontSize: mobile ? 22 : 20,
        color: TOKENS.ink,
        textTransform: 'uppercase',
        letterSpacing: '0.04em',
        paddingTop: 4,
      }}>Subscribe</div>
      <div>
        <p style={{ color: TOKENS.muted, fontSize: mobile ? 16 : 17, margin: '0 0 14px', maxWidth: 460 }}>
          Drop in your email — I'll send one when there's a new note. Or, if you prefer, here's the <FNLink>RSS feed ↗</FNLink>.
        </p>
        <form onSubmit={(e) => e.preventDefault()} style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <input type="email" placeholder="you@email.com" style={{
            flex: '1 1 200px', minWidth: 180, padding: '10px 0',
            border: 'none', borderBottom: `1.5px solid ${TOKENS.ink}`,
            background: 'transparent', color: TOKENS.ink, fontSize: 16,
            fontFamily: 'var(--font-atkinson)', outline: 'none',
          }} />
          <button type="submit" style={{
            padding: '10px 16px', background: 'transparent', color: TOKENS.ink,
            border: `1.5px solid ${TOKENS.ink}`, fontSize: 14, fontWeight: 700,
            cursor: 'pointer', fontFamily: 'var(--font-atkinson)',
            letterSpacing: '0.04em', textTransform: 'uppercase',
          }}>Send it →</button>
        </form>
      </div>
    </section>
  );
}

function NewsletterSheet({ mobile }) {
  return (
    <section style={{
      marginTop: mobile ? 32 : 48,
      padding: mobile ? 20 : '28px 32px',
      background: TOKENS.bgSoft,
      border: `1px dashed ${TOKENS.hairline}`,
      borderRadius: 6,
    }}>
      <div style={{
        fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase',
        color: TOKENS.muted, fontFamily: 'var(--font-atkinson)', marginBottom: 10,
      }}>The dispatch</div>
      <div style={{
        fontFamily: 'var(--font-display)', fontSize: mobile ? 26 : 30,
        color: TOKENS.ink, lineHeight: 1.15, marginBottom: 14,
      }}>One email when there's a new note. Otherwise silence.</div>
      <form onSubmit={(e) => e.preventDefault()} style={{
        display: 'flex', gap: 0, flexWrap: 'wrap',
        border: `1.5px solid ${TOKENS.ink}`, borderRadius: 4, overflow: 'hidden',
        maxWidth: 480,
      }}>
        <input type="email" placeholder="you@email.com" style={{
          flex: '1 1 200px', minWidth: 160, padding: '12px 14px',
          border: 'none', background: 'transparent',
          color: TOKENS.ink, fontSize: 16,
          fontFamily: 'var(--font-atkinson)', outline: 'none',
        }} />
        <button type="submit" style={{
          padding: '12px 18px', background: TOKENS.ink, color: TOKENS.bgSoft,
          border: 'none', fontSize: 14, fontWeight: 700, cursor: 'pointer',
          fontFamily: 'var(--font-atkinson)', letterSpacing: '0.04em',
          textTransform: 'uppercase',
        }}>Subscribe</button>
      </form>
      <div style={{ marginTop: 12, fontSize: 14, color: TOKENS.muted, fontFamily: 'var(--font-atkinson)' }}>
        Prefer feeds? <FNLink>RSS ↗</FNLink>
      </div>
    </section>
  );
}

Object.assign(window, {
  POSTS, TOKENS, CAT, CAT_NEUTRAL,
  useUnreadState, fmtDate, fmtShortDate,
  CategoryChip, UnreadDot, FNLink,
  SiteHeader, SiteFooter,
  NewsletterIndex, NewsletterLedger, NewsletterSheet,
});
