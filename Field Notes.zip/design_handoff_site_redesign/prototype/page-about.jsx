// page-about.jsx — About page.
// Hero (title + byline + italic dek), three body sections matching the
// site's category taxonomy (Building / Marketing / AI), a "Who I'm writing
// for" block, and a "What this isn't" note. Closes with the newsletter.

function AboutPage({ width = 1280, mobile = false }) {
  const contentMaxW = mobile ? '100%' : 720;
  const proseSize = mobile ? 17 : 19;
  const proseStyle = {
    fontFamily: 'var(--font-atkinson)',
    fontSize: proseSize,
    lineHeight: 1.65,
    color: TOKENS.ink,
    margin: '0 0 1.2em',
  };
  const h2Size = mobile ? 28 : 36;
  const h2Style = {
    fontFamily: 'var(--font-display)',
    fontSize: h2Size,
    lineHeight: 1.15,
    color: TOKENS.ink,
    margin: mobile ? '36px 0 18px' : '52px 0 22px',
    letterSpacing: '-0.01em',
  };

  return (
    <div style={{
      width: width,
      background: `linear-gradient(${TOKENS.bgSoft}, ${TOKENS.bg}) no-repeat`,
      backgroundColor: TOKENS.bg,
      backgroundSize: '100% 600px',
      color: TOKENS.ink,
      fontFamily: 'var(--font-atkinson)',
    }}>
      <FNHeader current="about" mobile={mobile} />

      <main style={{
        maxWidth: contentMaxW,
        margin: '0 auto',
        padding: mobile ? '32px 20px 48px' : '56px 40px 72px',
      }}>
        {/* Hero */}
        <header style={{ marginBottom: mobile ? 32 : 44 }}>
          <h1 style={{
            fontFamily: 'var(--font-display)',
            fontSize: mobile ? 56 : 88,
            margin: 0,
            lineHeight: 0.95,
            letterSpacing: '-0.01em',
            color: TOKENS.ink,
          }}>About</h1>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 10,
            marginTop: mobile ? 18 : 24, fontSize: 14, color: TOKENS.muted,
            paddingBottom: mobile ? 18 : 22,
            borderBottom: `1px solid ${TOKENS.hairlineSoft}`,
          }}>
            <strong style={{ color: TOKENS.ink, fontWeight: 700 }}>Will</strong>
            <span style={{ opacity: 0.4 }}>·</span>
            <span>Head of Marketing & CX</span>
            <span style={{ opacity: 0.4 }}>·</span>
            <span>UK</span>
          </div>
          <p style={{
            fontStyle: 'italic',
            color: TOKENS.muted,
            fontSize: mobile ? 19 : 22,
            lineHeight: 1.45,
            margin: mobile ? '22px 0 0' : '28px 0 0',
            maxWidth: 620,
          }}>
            Field notes from Will — Head of Marketing & Customer Experience at a UK
            education business — on building, marketing, and using AI in practice.
          </p>
        </header>

        {/* Intro paragraphs */}
        <section style={{ maxWidth: 680 }}>
          <p style={proseStyle}>
            I'm Will — Head of Marketing & Customer Experience at a UK education business,
            where I look after a marketing team, a lead generation function, and a customer
            solutions team.
          </p>
          <p style={proseStyle}>
            Most of what I do day-to-day sits at the intersection of three things: building
            an integrated acquisition and retention model, figuring out how AI actually
            changes marketing (rather than how it's supposed to), and helping a team of
            seven do their best work.
          </p>
          <p style={proseStyle}>
            This site is where I write about what I'm learning in the open.
          </p>
        </section>

        {/* What you'll find here */}
        <h2 style={h2Style}>What you'll find here</h2>
        <p style={{ ...proseStyle, maxWidth: 680 }}>
          Field Notes is a working notebook, not a thought-leadership outlet. Posts tend to
          fall into three categories:
        </p>

        <div style={{
          display: 'flex', flexDirection: 'column', gap: mobile ? 16 : 20,
          marginTop: mobile ? 16 : 20,
          marginBottom: mobile ? 16 : 24,
        }}>
          <AboutCategoryBlock
            tag="building"
            title="Things I'm building"
            mobile={mobile}
            body="AI tools, internal systems, websites, side projects. I show the work — what I tried, what broke, what I'd do differently. Most recently: an AI chatbot for our customer-facing site, a weekly meal-planning app built on the Claude API, and the site you're reading now."
          />
          <AboutCategoryBlock
            tag="marketing"
            title="Marketing thinking"
            mobile={mobile}
            body={`How I'm approaching the work — campaigns, team structure, customer experience, the retention/acquisition handoff, the awkward bits no one writes about. Less framework-shopping, more "here's what we tried and what happened."`}
          />
          <AboutCategoryBlock
            tag="ai"
            title="AI, practically"
            mobile={mobile}
            body="Where it earns its keep in real organisations, where it doesn't, and the gap between the demos and the day job. Written for colleagues and peers who are bored of the hype and want to know what's actually useful on a Tuesday morning."
          />
        </div>

        {/* Who I'm writing for */}
        <h2 style={h2Style}>Who I'm writing for</h2>
        <p style={{ ...proseStyle, maxWidth: 680 }}>
          People doing the work, not watching it. Marketers, operators, team leads, anyone
          trying to integrate AI into a real organisation with real constraints. If you're
          senior enough that no one above you knows the answer either, you'll probably find
          something useful here.
        </p>

        {/* A note on what this isn't */}
        <h2 style={h2Style}>A note on what this isn't</h2>
        <p style={{ ...proseStyle, maxWidth: 680 }}>
          I'm not selling anything. I'm not a consultant. I don't have a course. I'm a
          practitioner figuring it out in public — which means I'll be wrong sometimes, and
          I'd rather be wrong out loud than vague in private.
        </p>

        <NewsletterBlock mobile={mobile} />
      </main>

      <FNFooter mobile={mobile} />
    </div>
  );
}

function AboutCategoryBlock({ tag, title, body, mobile }) {
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'grid',
        gridTemplateColumns: mobile ? '1fr' : '180px 1fr',
        gap: mobile ? 10 : 24,
        padding: mobile ? '16px 0' : '20px 0',
        borderTop: `1px solid ${TOKENS.hairlineSoft}`,
        position: 'relative',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', flexDirection: 'column', gap: 10 }}>
        <CategoryChip tag={tag} size="lg" />
        <FNLink style={{ fontSize: 13 }}>Browse →</FNLink>
      </div>
      <div>
        <div style={{
          fontFamily: 'var(--font-display)',
          fontSize: mobile ? 20 : 22,
          color: TOKENS.ink,
          marginBottom: 8,
          lineHeight: 1.2,
        }}>{title}</div>
        <p style={{
          color: TOKENS.muted,
          fontSize: mobile ? 16 : 17,
          margin: 0,
          lineHeight: 1.55,
          maxWidth: 560,
        }}>{body}</p>
      </div>
    </div>
  );
}

Object.assign(window, { AboutPage });
