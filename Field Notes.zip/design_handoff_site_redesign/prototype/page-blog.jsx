// page-blog.jsx — Blog index in V1 vocabulary.
// Same shape as VariantIndex, refactored to share the FNHeader / FNFooter /
// PageTitle / PostRow / NewsletterBlock atoms with the rest of the site.

function BlogPage({ width = 1280, mobile = false, tweaks }) {
  const { isRead, toggle, reset } = useUnreadState();
  const t = tweaks || {};
  const showExcerpts = t.showExcerpts !== false;
  const colored = t.coloredCategories !== false;
  const density = t.density || 'cozy';

  const contentMaxW = mobile ? '100%' : 720;
  const rowPad = density === 'compact' ? (mobile ? 18 : 22) : (mobile ? 26 : 32);
  const unreadCount = POSTS.filter((p) => !isRead(p.slug)).length;

  return (
    <div style={{
      width: width,
      background: `linear-gradient(${TOKENS.bgSoft}, ${TOKENS.bg}) no-repeat`,
      backgroundColor: TOKENS.bg,
      backgroundSize: '100% 600px',
      color: TOKENS.ink,
      fontFamily: 'var(--font-atkinson)',
    }}>
      <FNHeader current="blog" mobile={mobile} />

      <main style={{
        maxWidth: contentMaxW,
        margin: '0 auto',
        padding: mobile ? '32px 20px 48px' : '56px 40px 72px',
      }}>
        <PageTitle
          title="Blog"
          count={POSTS.length}
          countLabel="posts"
          subtitle="What I'm working through, in the open. Newest first."
          sideLink={<FNLink style={{ fontSize: 13 }}>RSS ↗</FNLink>}
          mobile={mobile}
        />

        <div style={{
          fontSize: 12,
          color: TOKENS.mutedSoft,
          fontFamily: 'var(--font-atkinson)',
          marginTop: 14,
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <span style={{
            width: 8, height: 8, borderRadius: '50%', background: TOKENS.accent,
            display: 'inline-block', boxShadow: `0 0 0 1px ${TOKENS.accent}`,
          }} />
          <span>= unread · {unreadCount} of {POSTS.length}</span>
          <button onClick={reset} style={{
            background: 'transparent', border: 'none', color: TOKENS.accentInk,
            cursor: 'pointer', fontSize: 12, padding: 0, fontFamily: 'var(--font-atkinson)',
            textDecoration: 'underline', textDecorationColor: TOKENS.accent, textDecorationThickness: 1,
            marginLeft: 'auto',
          }}>mark all unread</button>
        </div>

        <HRule mobile={mobile} />

        <ol style={{ listStyle: 'none', margin: 0, padding: 0 }}>
          {POSTS.map((p, i) => (
            <PostRow
              key={p.slug}
              post={p}
              unread={!isRead(p.slug)}
              onToggle={() => toggle(p.slug)}
              mobile={mobile}
              showExcerpt={showExcerpts}
              colored={colored}
              compact={density === 'compact'}
            />
          ))}
        </ol>

        <NewsletterBlock mobile={mobile} />
      </main>

      <FNFooter mobile={mobile} />
    </div>
  );
}

Object.assign(window, { BlogPage });
