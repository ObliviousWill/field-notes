// page-home.jsx — Field Notes home page in V1 vocabulary.
// Hero (title, dek, "more about" link), Currently-building strip,
// Recent posts (compact V1 rows), newsletter block.

function HomePage({ width = 1280, mobile = false }) {
  const { isRead, toggle } = useUnreadState();
  const contentMaxW = mobile ? '100%' : 720;
  const recent = POSTS.slice(0, 3);
  const building = PROJECTS.filter((p) => p.status === 'building');

  return (
    <div style={{
      width: width,
      background: `linear-gradient(${TOKENS.bgSoft}, ${TOKENS.bg}) no-repeat`,
      backgroundColor: TOKENS.bg,
      backgroundSize: '100% 600px',
      color: TOKENS.ink,
      fontFamily: 'var(--font-atkinson)',
    }}>
      <FNHeader current="home" mobile={mobile} />

      <main style={{
        maxWidth: contentMaxW,
        margin: '0 auto',
        padding: mobile ? '32px 20px 48px' : '64px 40px 80px',
      }}>
        {/* Hero */}
        <section>
          <div style={{
            fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase',
            color: TOKENS.muted, marginBottom: 12,
          }}>A working notebook</div>
          <h1 style={{
            fontFamily: 'var(--font-display)',
            fontSize: mobile ? 56 : 92,
            margin: 0,
            lineHeight: 0.95,
            letterSpacing: '-0.01em',
            color: TOKENS.ink,
          }}>Field Notes</h1>
          <p style={{
            color: TOKENS.muted,
            fontSize: mobile ? 18 : 22,
            margin: mobile ? '18px 0 22px' : '24px 0 28px',
            maxWidth: 580,
            lineHeight: 1.45,
          }}>
            Notes from the field on marketing, building, and AI in practice — written
            in the open by someone doing the work, not watching it.
          </p>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap',
            color: TOKENS.muted, fontSize: 15,
          }}>
            <span>New posts roughly weekly.</span>
            <FNLink>More about this site →</FNLink>
          </div>
        </section>

        <HRule mobile={mobile} />

        {/* Currently building */}
        <section>
          <SectionHeading
            title="Currently building"
            mobile={mobile}
            top={false}
            sideLink={<FNLink style={{ fontSize: 14 }}>All projects →</FNLink>}
          />
          <div style={{ display: 'flex', flexDirection: 'column', gap: mobile ? 14 : 18 }}>
            {building.slice(0, 1).map((p) => (
              <ProjectCard key={p.slug} project={p} mobile={mobile} />
            ))}
          </div>
        </section>

        {/* Recent posts */}
        <section style={{ marginTop: mobile ? 36 : 56 }}>
          <SectionHeading
            title="Recent posts"
            mobile={mobile}
            top={false}
            sideLink={<FNLink style={{ fontSize: 14 }}>All posts →</FNLink>}
          />
          <ol style={{ listStyle: 'none', margin: 0, padding: 0 }}>
            {recent.map((p) => (
              <PostRow
                key={p.slug}
                post={p}
                unread={!isRead(p.slug)}
                onToggle={() => toggle(p.slug)}
                mobile={mobile}
                compact
              />
            ))}
          </ol>
        </section>

        <NewsletterBlock mobile={mobile} />
      </main>

      <FNFooter mobile={mobile} />
    </div>
  );
}

Object.assign(window, { HomePage });
