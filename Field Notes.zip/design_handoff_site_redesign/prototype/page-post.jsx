// page-post.jsx — Individual post page.
// Reading-progress bar, post header (category/title/dek/byline), generous
// long-form typography for the body, mentions sidebar, prev/next + newsletter.

function PostPage({ width = 1280, mobile = false }) {
  const post = POSTS[0]; // "How to get the most out of your AI"
  const nextPost = POSTS[1];
  const contentMaxW = mobile ? '100%' : 720;

  return (
    <div style={{
      width: width,
      background: `linear-gradient(${TOKENS.bgSoft}, ${TOKENS.bg}) no-repeat`,
      backgroundColor: TOKENS.bg,
      backgroundSize: '100% 600px',
      color: TOKENS.ink,
      fontFamily: 'var(--font-atkinson)',
      position: 'relative',
    }}>
      <FNHeader current="blog" mobile={mobile} />

      {/* Reading progress bar — fixed visual representation of ~32% read */}
      <div style={{
        height: 3,
        background: TOKENS.hairlineSoft,
        position: 'relative',
      }}>
        <div style={{
          position: 'absolute', inset: '0 auto 0 0',
          width: '32%',
          background: TOKENS.accent,
          transition: 'width 200ms ease',
        }} />
      </div>

      <main style={{
        maxWidth: contentMaxW,
        margin: '0 auto',
        padding: mobile ? '24px 20px 48px' : '40px 40px 72px',
      }}>
        {/* Top breadcrumb */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          marginBottom: mobile ? 24 : 36, fontSize: 13, color: TOKENS.muted, flexWrap: 'wrap', gap: 8,
        }}>
          <FNLink>← All notes</FNLink>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <span style={{
              width: 6, height: 6, borderRadius: '50%', background: TOKENS.accent,
            }} />
            <span style={{ letterSpacing: '0.06em', textTransform: 'uppercase', fontSize: 11 }}>
              ~3 min left of {post.readTime}
            </span>
          </span>
        </div>

        {/* Post header */}
        <header style={{ marginBottom: mobile ? 28 : 40 }}>
          <div style={{
            display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap',
          }}>
            {post.tags.map((tag) => (
              <CategoryChip key={tag} tag={tag} size="lg" />
            ))}
          </div>
          <h1 style={{
            fontFamily: 'var(--font-display)',
            fontSize: mobile ? 36 : 56,
            margin: 0,
            lineHeight: 1.08,
            letterSpacing: '-0.01em',
            color: TOKENS.ink,
            textWrap: 'pretty',
          }}>{post.title}</h1>
          <p style={{
            fontStyle: 'italic',
            color: TOKENS.muted,
            fontSize: mobile ? 19 : 22,
            lineHeight: 1.45,
            margin: mobile ? '18px 0 22px' : '24px 0 28px',
            maxWidth: 620,
          }}>{post.description}</p>
          <div style={{
            display: 'flex', alignItems: 'center', flexWrap: 'wrap',
            gap: 10, fontSize: 14, color: TOKENS.muted,
            paddingTop: mobile ? 18 : 22,
            borderTop: `1px solid ${TOKENS.hairlineSoft}`,
          }}>
            <strong style={{ color: TOKENS.ink, fontWeight: 700 }}>Will</strong>
            <span style={{ opacity: 0.4 }}>·</span>
            <span>{fmtDate(post.date)}</span>
            <span style={{ opacity: 0.4 }}>·</span>
            <span>{post.readTime} min read</span>
          </div>
        </header>

        {/* Body */}
        <PostBody mobile={mobile} />

        {/* Mentions / cross-links */}
        <PostMentions mobile={mobile} />

        {/* Footer — next post + newsletter */}
        <section style={{
          marginTop: mobile ? 40 : 64,
          paddingTop: mobile ? 28 : 36,
          borderTop: `1px solid ${TOKENS.hairline}`,
        }}>
          <div style={{
            fontSize: 11, letterSpacing: '0.16em', textTransform: 'uppercase',
            color: TOKENS.muted, marginBottom: 12,
          }}>Next note</div>
          <PostRow post={nextPost} unread={true} onToggle={() => {}} mobile={mobile} compact />
        </section>

        <NewsletterBlock mobile={mobile} />
      </main>

      <FNFooter mobile={mobile} />
    </div>
  );
}

// Real body content from "How to get the most out of your AI" — abridged.
function PostBody({ mobile }) {
  const proseSize = mobile ? 17 : 19;
  const h2Size = mobile ? 28 : 36;
  const proseStyle = {
    fontFamily: 'var(--font-atkinson)',
    fontSize: proseSize,
    lineHeight: 1.65,
    color: TOKENS.ink,
    margin: '0 0 1.4em',
  };
  return (
    <article style={{ maxWidth: 680 }}>
      <p style={proseStyle}>
        I use AI every day, across just about everything. Claude is the one I reach for
        most — writing, thinking, design, code. When you've used enough of these tools,
        you stop noticing the differences between them and start noticing the one thing
        that decides whether you get brilliant work or mediocre work out of any of them.
      </p>
      <p style={proseStyle}>
        And it's not the tool. It's how you use it.
      </p>
      <p style={proseStyle}>
        Most people open an AI assistant, type a question the way they'd type it into
        Google, read the answer, and close the tab. It works well enough that they never
        question it, and because it works well enough they never find out they're getting
        a fraction of what's on offer. <strong>The model isn't the limit. You are.</strong>
        That's fixable, and the fixes carry across.
      </p>

      <blockquote style={{
        borderLeft: `4px solid ${TOKENS.accent}`,
        padding: '4px 0 4px 22px',
        margin: mobile ? '32px 0' : '40px 0',
        fontSize: mobile ? 21 : 26,
        lineHeight: 1.4,
        fontFamily: 'var(--font-display)',
        color: TOKENS.ink,
        fontWeight: 400,
      }}>
        A search box answers the question you typed. AI does its best work when you treat
        it as something you set up, direct, and build with.
      </blockquote>

      <h2 style={{
        fontFamily: 'var(--font-display)',
        fontSize: h2Size,
        lineHeight: 1.15,
        color: TOKENS.ink,
        margin: mobile ? '40px 0 18px' : '56px 0 22px',
        letterSpacing: '-0.01em',
      }}>1. Setup: stop introducing yourself every single time</h2>

      <p style={proseStyle}>
        Picture hiring a brilliant assistant and then, every morning, pretending you've
        never met. You re-explain your job, your company, how you like things written, what
        you're working on — every day, from scratch. That's what using Claude with no setup is.
      </p>
      <p style={proseStyle}>
        There are two things worth setting up once, and they pay back every conversation
        after.
      </p>

      <ol style={{
        ...proseStyle,
        paddingLeft: 22,
        margin: '0 0 1.6em',
      }}>
        <li style={{ marginBottom: 14 }}>
          <strong>Your profile.</strong> The standing brief on who you are and how you want
          Claude to respond. Not your life story — the few facts that change the answer.
        </li>
        <li style={{ marginBottom: 14 }}>
          <strong>Memory.</strong> Claude can carry useful context from past conversations
          forward, so the thing you explained on Tuesday is still there on Friday.
        </li>
      </ol>

      <p style={proseStyle}>
        Setup isn't a settings-screen chore you do once and forget. The mindset is that{' '}
        <strong>context is the product</strong>. Almost every disappointing answer is a
        context failure: you knew something the model didn't, and you didn't say it.
      </p>

      <h2 style={{
        fontFamily: 'var(--font-display)',
        fontSize: h2Size,
        lineHeight: 1.15,
        color: TOKENS.ink,
        margin: mobile ? '40px 0 18px' : '56px 0 22px',
        letterSpacing: '-0.01em',
      }}>2. Direction: the difference between a question and a brief</h2>

      <p style={proseStyle}>
        This is where the real craft lives, and it's almost absent from every guide I've
        read. Watch the difference. Here's the search-box version:
      </p>

      <p style={{
        ...proseStyle,
        background: TOKENS.bgTint,
        padding: mobile ? '14px 16px' : '18px 22px',
        borderRadius: 6,
        fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
        fontSize: mobile ? 15 : 16,
        margin: '0 0 1.4em',
      }}>
        Write a follow-up email to a prospect who went quiet.
      </p>

      <p style={proseStyle}>
        You'll get a perfectly serviceable, perfectly generic email. The kind you'd delete
        from your own inbox. The skill isn't clever wording. It's the discipline of emptying
        your head onto the page before you ask.
      </p>

      <p style={{
        ...proseStyle,
        color: TOKENS.muted,
        fontSize: mobile ? 15 : 16,
        margin: mobile ? '36px 0 0' : '48px 0 0',
      }}>
        <em>This is the first ~30% of the post — the full version covers Direction in detail
        and the third mode: Building. Treat the body type above as the canonical look for
        long-form notes.</em>
      </p>
    </article>
  );
}

function PostMentions({ mobile }) {
  return (
    <aside style={{
      marginTop: mobile ? 36 : 56,
      padding: mobile ? '20px 0 0' : '28px 0 0',
      borderTop: `1px solid ${TOKENS.hairlineSoft}`,
      display: 'grid',
      gridTemplateColumns: mobile ? '1fr' : '180px 1fr',
      gap: mobile ? 12 : 28,
    }}>
      <div style={{
        fontFamily: 'var(--font-display)',
        fontSize: mobile ? 18 : 20,
        textTransform: 'uppercase',
        letterSpacing: '0.04em',
        color: TOKENS.ink,
      }}>Mentions</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 12,
          padding: '10px 14px',
          background: TOKENS.bgSoft,
          border: `1px solid ${TOKENS.hairlineSoft}`,
          borderRadius: 6,
          fontSize: 14, color: TOKENS.muted,
        }}>
          <StatusPill status="building" />
          <FNLink style={{ fontSize: 15, fontWeight: 700 }}>Field Notes (this site)</FNLink>
          <span style={{ flex: 1 }} />
          <span style={{
            fontSize: 11, letterSpacing: '0.06em', textTransform: 'uppercase',
          }}>Project ↗</span>
        </div>
      </div>
    </aside>
  );
}

Object.assign(window, { PostPage });
