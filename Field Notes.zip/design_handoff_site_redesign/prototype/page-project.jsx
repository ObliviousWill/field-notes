// page-project.jsx — Project detail page.
// Header (status, title, summary), quick-facts strip, updates timeline,
// related posts, footer.

const FIELD_NOTES_PROJECT = {
  slug: 'field-notes',
  title: 'Field Notes (this site)',
  summary: "A personal site built in the open with Claude Code as the only collaborator. The brief: see how far a non-developer can take a website end to end, and show the work as I go.",
  status: 'building',
  startDate: '2026-05-20',
  description: "This is the site you're on. Built from a blank repo, deployed via GitHub Pages, no builder and no agency. Every change ships through a commit, so the project's progress is visible in the git history as well as in the updates below. The goal isn't a portfolio piece. It's a record of decisions: what I tried, what I changed my mind about, what worked.",
  facts: [
    ['Tech', 'Astro · GitHub Pages · Claude Code'],
    ['Status', 'Currently building'],
    ['Hosting', 'Free (GitHub Pages)'],
    ['Cost', '£10/yr (domain)'],
  ],
  links: [
    { label: 'GitHub repo', url: '#' },
  ],
};

const UPDATES = [
  {
    title: 'Foundation in place',
    date: '2026-05-20',
    body: [
      "Most of the scaffolding is done. The site is live on GitHub Pages, three pages render, and the first post is out.",
    ],
    sections: [
      {
        heading: "What's here",
        items: [
          ['Astro blog starter', 'scaffolded from npm create astro@latest and configured for the /field-notes base path on GitHub Pages.'],
          ['A theme of my own', 'cream #EEE9DF, slate #2C3B4D, amber #FFB162. Body text passes WCAG AAA against the cream; the amber is reserved for fills and borders.'],
          ['Logo and favicon', 'designed in Canva and dropped into the repo as SVG. Header centred on a 3-column grid so the nav stays dead-centre regardless of what flanks it.'],
          ['Post layout', 'byline, italic dek, sticky right-rail TOC, and a tight tag taxonomy (building, marketing, ai).'],
        ],
      },
      {
        heading: "What's next",
        items: [
          ['This project page and its update feed', 'the bit you\'re reading.'],
          ['Write more', 'a handful more posts before promoting widely, so the site reads lived-in rather than just-launched.'],
          ['Add more projects', 'other artefacts in flight get their own project pages with the same update-log pattern.'],
          ['A real typography pass', 'line length, code-block styling, blockquote treatment.'],
        ],
      },
    ],
  },
];

function ProjectPage({ width = 1280, mobile = false }) {
  const project = FIELD_NOTES_PROJECT;
  const contentMaxW = mobile ? '100%' : 760;

  // Posts that mention this project
  const relatedPosts = POSTS.filter((p) => p.mentions && p.mentions.some((m) => m.slug === project.slug));

  return (
    <div style={{
      width: width,
      background: `linear-gradient(${TOKENS.bgSoft}, ${TOKENS.bg}) no-repeat`,
      backgroundColor: TOKENS.bg,
      backgroundSize: '100% 600px',
      color: TOKENS.ink,
      fontFamily: 'var(--font-atkinson)',
    }}>
      <FNHeader current="projects" mobile={mobile} />

      <main style={{
        maxWidth: contentMaxW,
        margin: '0 auto',
        padding: mobile ? '24px 20px 48px' : '40px 40px 72px',
      }}>
        {/* Top breadcrumb */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          marginBottom: mobile ? 22 : 32, fontSize: 13, color: TOKENS.muted, flexWrap: 'wrap', gap: 8,
        }}>
          <FNLink>← All projects</FNLink>
          <FNLink style={{ fontSize: 13 }}>↗ GitHub repo</FNLink>
        </div>

        {/* Header */}
        <header style={{ marginBottom: mobile ? 28 : 36 }}>
          <div style={{
            display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap',
            marginBottom: 16,
          }}>
            <StatusPill status={project.status} />
            <span style={{ fontSize: 13, color: TOKENS.muted }}>
              Started {fmtDate(project.startDate)}
            </span>
          </div>
          <h1 style={{
            fontFamily: 'var(--font-display)',
            fontSize: mobile ? 40 : 60,
            margin: 0,
            lineHeight: 1.05,
            letterSpacing: '-0.01em',
            color: TOKENS.ink,
          }}>{project.title}</h1>
          <p style={{
            fontStyle: 'italic',
            color: TOKENS.muted,
            fontSize: mobile ? 18 : 21,
            lineHeight: 1.5,
            margin: mobile ? '16px 0 0' : '20px 0 0',
            maxWidth: 620,
          }}>{project.summary}</p>
        </header>

        {/* Quick facts strip */}
        <section style={{
          padding: mobile ? '14px 16px' : '18px 22px',
          background: TOKENS.bgSoft,
          border: `1px solid ${TOKENS.hairlineSoft}`,
          borderRadius: 8,
          marginBottom: mobile ? 32 : 44,
          display: 'grid',
          gridTemplateColumns: mobile ? '1fr' : 'repeat(4, 1fr)',
          gap: mobile ? 10 : 16,
        }}>
          {project.facts.map(([k, v]) => (
            <div key={k} style={{ minWidth: 0 }}>
              <div style={{
                fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase',
                color: TOKENS.muted, marginBottom: 4,
              }}>{k}</div>
              <div style={{
                fontSize: mobile ? 15 : 15, color: TOKENS.ink, lineHeight: 1.4,
              }}>{v}</div>
            </div>
          ))}
        </section>

        {/* Description */}
        <section style={{ maxWidth: 680, marginBottom: mobile ? 36 : 48 }}>
          <p style={{
            fontSize: mobile ? 17 : 19,
            lineHeight: 1.65,
            color: TOKENS.ink,
            margin: 0,
          }}>{project.description}</p>
        </section>

        {/* Updates timeline */}
        <SectionHeading
          title="Updates"
          mobile={mobile}
          top={false}
          sideLink={
            <span style={{
              fontSize: 11, letterSpacing: '0.10em', textTransform: 'uppercase',
              color: TOKENS.muted, display: 'inline-flex', alignItems: 'center', gap: 6,
            }}>
              <span style={{
                width: 6, height: 6, borderRadius: '50%', background: TOKENS.accent,
              }} />
              {UPDATES.length} {UPDATES.length === 1 ? 'entry' : 'entries'}
            </span>
          }
        />
        <div>
          {UPDATES.map((u, i) => (
            <UpdateEntry key={i} update={u} mobile={mobile} isFirst={i === 0} isLast={i === UPDATES.length - 1} />
          ))}
        </div>

        {/* Related posts */}
        {relatedPosts.length > 0 && (
          <section style={{ marginTop: mobile ? 36 : 56 }}>
            <SectionHeading title="Related posts" mobile={mobile} top={false} />
            <ol style={{ listStyle: 'none', margin: 0, padding: 0 }}>
              {relatedPosts.map((p) => (
                <PostRow key={p.slug} post={p} unread={true} onToggle={() => {}} mobile={mobile} compact />
              ))}
            </ol>
          </section>
        )}

        <NewsletterBlock mobile={mobile} />
      </main>

      <FNFooter mobile={mobile} />
    </div>
  );
}

function UpdateEntry({ update, mobile, isFirst, isLast }) {
  const gutterW = mobile ? 70 : 100;
  return (
    <article style={{
      display: 'grid',
      gridTemplateColumns: `${gutterW}px 1fr`,
      gap: mobile ? 14 : 28,
      position: 'relative',
      paddingBottom: mobile ? 28 : 40,
    }}>
      {/* Gutter — date + timeline dot */}
      <div style={{ position: 'relative', textAlign: 'right', paddingRight: mobile ? 10 : 14 }}>
        <div style={{
          fontSize: mobile ? 12 : 13,
          letterSpacing: '0.06em',
          textTransform: 'uppercase',
          color: TOKENS.muted,
          fontFamily: 'var(--font-atkinson)',
          lineHeight: 1.4,
        }}>
          {fmtShortDate(update.date).day} {fmtShortDate(update.date).mon}
          <div style={{ fontSize: 11, color: TOKENS.mutedSoft }}>{fmtShortDate(update.date).year}</div>
        </div>
      </div>
      {/* Timeline line + dot */}
      <div style={{
        position: 'absolute',
        left: gutterW,
        top: 8,
        bottom: isLast ? '50%' : 0,
        width: 2,
        background: TOKENS.hairlineSoft,
        marginLeft: -1,
      }} />
      <div style={{
        position: 'absolute',
        left: gutterW - 6,
        top: 6,
        width: 10,
        height: 10,
        borderRadius: '50%',
        background: isFirst ? TOKENS.accent : TOKENS.bg,
        boxShadow: `0 0 0 2px ${isFirst ? TOKENS.accent : TOKENS.hairline}`,
      }} />

      {/* Body */}
      <div style={{ paddingLeft: mobile ? 12 : 18, minWidth: 0 }}>
        <h3 style={{
          fontFamily: 'var(--font-display)',
          fontSize: mobile ? 22 : 28,
          margin: 0,
          lineHeight: 1.15,
          color: TOKENS.ink,
          letterSpacing: '-0.005em',
        }}>{update.title}</h3>
        {update.body.map((para, i) => (
          <p key={i} style={{
            color: TOKENS.ink,
            fontSize: mobile ? 16 : 17,
            lineHeight: 1.6,
            margin: mobile ? '12px 0 0' : '14px 0 0',
            maxWidth: 600,
          }}>{para}</p>
        ))}
        {update.sections && update.sections.map((s, i) => (
          <div key={i} style={{ marginTop: mobile ? 22 : 26 }}>
            <h4 style={{
              fontFamily: 'var(--font-display)',
              fontSize: mobile ? 17 : 19,
              margin: '0 0 12px',
              color: TOKENS.ink,
              lineHeight: 1.2,
            }}>{s.heading}</h4>
            <ul style={{ margin: 0, padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 10 }}>
              {s.items.map(([label, body], j) => (
                <li key={j} style={{
                  fontSize: mobile ? 15 : 16,
                  lineHeight: 1.55,
                  color: TOKENS.muted,
                  paddingLeft: 16,
                  position: 'relative',
                  maxWidth: 600,
                }}>
                  <span style={{
                    position: 'absolute',
                    left: 0,
                    top: '0.6em',
                    width: 6,
                    height: 6,
                    background: TOKENS.accent,
                    borderRadius: 1,
                  }} />
                  <strong style={{ color: TOKENS.ink, fontWeight: 700 }}>{label}.</strong>{' '}{body}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </article>
  );
}

Object.assign(window, { ProjectPage });
