// page-projects.jsx — Projects index.
// PageTitle, then a grid of ProjectCards grouped by status.

function ProjectsPage({ width = 1280, mobile = false }) {
  const contentMaxW = mobile ? '100%' : 760;

  const building = PROJECTS.filter((p) => p.status === 'building');
  const paused = PROJECTS.filter((p) => p.status === 'paused');
  const shipped = PROJECTS.filter((p) => p.status === 'shipped');

  return (
    <div style={{
      width: width,
      background: `linear-gradient(${TOKENS.bgSoft}, ${TOKENS.bg}) no-repeat`,
      backgroundColor: TOKENS.bg,
      backgroundSize: '100% 600px',
      color: TOKENS.ink,
      fontFamily: 'var(--font-atkinson)',
    }}>
      <FNHeader current="projects" mobile={mobile} />

      <main style={{
        maxWidth: contentMaxW,
        margin: '0 auto',
        padding: mobile ? '32px 20px 48px' : '56px 40px 72px',
      }}>
        <PageTitle
          title="Projects"
          count={PROJECTS.length}
          countLabel={PROJECTS.length === 1 ? 'project' : 'projects'}
          subtitle="What I'm building, with the work shown — decisions, dead ends, screenshots, and what I'd do differently. Each project has its own page with a running log of updates."
          sideLink={<FNLink style={{ fontSize: 13 }}>RSS ↗</FNLink>}
          mobile={mobile}
        />

        {/* Status legend */}
        <div style={{
          fontSize: 12,
          color: TOKENS.muted,
          fontFamily: 'var(--font-atkinson)',
          marginTop: 14,
          display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap',
        }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <StatusPill status="building" /> active
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <StatusPill status="paused" /> on hold
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <StatusPill status="shipped" /> done
          </span>
        </div>

        <HRule mobile={mobile} />

        {building.length > 0 && (
          <ProjectGroup
            label="Active"
            items={building}
            mobile={mobile}
          />
        )}

        {paused.length > 0 && (
          <ProjectGroup
            label="On hold"
            items={paused}
            mobile={mobile}
            top={building.length > 0}
          />
        )}

        {shipped.length > 0 && (
          <ProjectGroup
            label="Shipped"
            items={shipped}
            mobile={mobile}
            top={building.length > 0 || paused.length > 0}
          />
        )}

        {/* Cross-link to the blog */}
        <section style={{
          marginTop: mobile ? 36 : 56,
          padding: mobile ? 18 : 24,
          background: TOKENS.bgSoft,
          border: `1px dashed ${TOKENS.hairlineSoft}`,
          borderRadius: 8,
          display: 'grid',
          gridTemplateColumns: mobile ? '1fr' : '1fr auto',
          gap: 12,
          alignItems: 'center',
        }}>
          <div>
            <div style={{
              fontFamily: 'var(--font-display)',
              fontSize: mobile ? 20 : 22,
              color: TOKENS.ink, marginBottom: 6,
              lineHeight: 1.2,
            }}>The blog tracks the thinking around these.</div>
            <p style={{ color: TOKENS.muted, margin: 0, fontSize: mobile ? 15 : 16, lineHeight: 1.5 }}>
              Posts mention specific projects where they come up — look for the "↗ Mentions" line under each title.
            </p>
          </div>
          <FNLink style={{ fontSize: 14 }}>Go to the blog →</FNLink>
        </section>
      </main>

      <FNFooter mobile={mobile} />
    </div>
  );
}

function ProjectGroup({ label, items, mobile, top = false }) {
  return (
    <section style={{ marginTop: top ? (mobile ? 36 : 48) : 0 }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 14,
        marginBottom: mobile ? 14 : 18,
      }}>
        <span style={{
          fontFamily: 'var(--font-display)', fontSize: mobile ? 20 : 22,
          color: TOKENS.ink, lineHeight: 1,
        }}>{label}</span>
        <span style={{ flex: 1, height: 1, background: TOKENS.hairlineSoft }} />
        <span style={{
          fontSize: 11, letterSpacing: '0.10em', textTransform: 'uppercase',
          color: TOKENS.muted,
        }}>{items.length}</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: mobile ? 14 : 18 }}>
        {items.map((p) => (
          <ProjectCard key={p.slug} project={p} mobile={mobile} expanded />
        ))}
      </div>
    </section>
  );
}

Object.assign(window, { ProjectsPage });
