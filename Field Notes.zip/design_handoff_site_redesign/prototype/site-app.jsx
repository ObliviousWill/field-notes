// site-app.jsx — full Field Notes redesign in V1 vocabulary.
// Each page rendered at desktop (1280) and mobile (390).

const DEFAULT_TWEAKS = /*EDITMODE-BEGIN*/{
  "showExcerpts": true,
  "coloredCategories": true,
  "density": "cozy"
}/*EDITMODE-END*/;

function SiteApp() {
  const [t, setTweak] = useTweaks(DEFAULT_TWEAKS);

  // Page heights — generous so the full header → footer is captured.
  const H_HOME = 1700;
  const H_BLOG = 2000;
  const H_POST = 2600;
  const H_PROJECTS = 1900;
  const H_PROJECT = 2400;
  const H_ABOUT = 2100;

  const H_HOME_M = 2100;
  const H_BLOG_M = 2500;
  const H_POST_M = 3300;
  const H_PROJECTS_M = 2400;
  const H_PROJECT_M = 3100;
  const H_ABOUT_M = 2800;

  return (
    <React.Fragment>
      <DesignCanvas>
        <DCSection id="home" title="Home" subtitle="Tagline, currently-building strip, recent posts, newsletter.">
          <DCArtboard id="home-desktop" label="Desktop · 1280" width={1280} height={H_HOME}>
            <HomePage width={1280} mobile={false} />
          </DCArtboard>
          <DCArtboard id="home-mobile" label="Mobile · 390" width={390} height={H_HOME_M}>
            <HomePage width={390} mobile={true} />
          </DCArtboard>
        </DCSection>

        <DCSection id="blog" title="Blog index" subtitle="V1 — refined sparse list. Tweaks panel drives density, excerpts, color coding.">
          <DCArtboard id="blog-desktop" label="Desktop · 1280" width={1280} height={H_BLOG}>
            <BlogPage width={1280} mobile={false} tweaks={t} />
          </DCArtboard>
          <DCArtboard id="blog-mobile" label="Mobile · 390" width={390} height={H_BLOG_M}>
            <BlogPage width={390} mobile={true} tweaks={t} />
          </DCArtboard>
        </DCSection>

        <DCSection id="post" title="Post page" subtitle="Reading-progress bar, category-tagged header, long-form typography, mentions, next note + newsletter.">
          <DCArtboard id="post-desktop" label="Desktop · 1280" width={1280} height={H_POST}>
            <PostPage width={1280} mobile={false} />
          </DCArtboard>
          <DCArtboard id="post-mobile" label="Mobile · 390" width={390} height={H_POST_M}>
            <PostPage width={390} mobile={true} />
          </DCArtboard>
        </DCSection>

        <DCSection id="projects" title="Projects index" subtitle="Grouped by status (Active / On hold / Shipped) with the same card vocabulary used on Home.">
          <DCArtboard id="projects-desktop" label="Desktop · 1280" width={1280} height={H_PROJECTS}>
            <ProjectsPage width={1280} mobile={false} />
          </DCArtboard>
          <DCArtboard id="projects-mobile" label="Mobile · 390" width={390} height={H_PROJECTS_M}>
            <ProjectsPage width={390} mobile={true} />
          </DCArtboard>
        </DCSection>

        <DCSection id="project" title="Project detail" subtitle="Status, quick-facts strip, updates timeline (real content from the Field Notes foundation update), related posts.">
          <DCArtboard id="project-desktop" label="Desktop · 1280" width={1280} height={H_PROJECT}>
            <ProjectPage width={1280} mobile={false} />
          </DCArtboard>
          <DCArtboard id="project-mobile" label="Mobile · 390" width={390} height={H_PROJECT_M}>
            <ProjectPage width={390} mobile={true} />
          </DCArtboard>
        </DCSection>

        <DCSection id="about" title="About" subtitle="Big display title with byline, italic dek, three category cards, then 'who I'm writing for' and 'what this isn't' sections.">
          <DCArtboard id="about-desktop" label="Desktop · 1280" width={1280} height={H_ABOUT}>
            <AboutPage width={1280} mobile={false} />
          </DCArtboard>
          <DCArtboard id="about-mobile" label="Mobile · 390" width={390} height={H_ABOUT_M}>
            <AboutPage width={390} mobile={true} />
          </DCArtboard>
        </DCSection>
      </DesignCanvas>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Layout">
          <TweakRadio
            label="Density"
            value={t.density}
            options={[
              { value: 'cozy', label: 'Cozy' },
              { value: 'compact', label: 'Compact' },
            ]}
            onChange={(v) => setTweak('density', v)}
          />
          <TweakToggle
            label="Show excerpts"
            value={t.showExcerpts}
            onChange={(v) => setTweak('showExcerpts', v)}
          />
          <TweakToggle
            label="Color-coded categories"
            value={t.coloredCategories}
            onChange={(v) => setTweak('coloredCategories', v)}
          />
        </TweakSection>
        <TweakSection label="Reading state">
          <TweakButton
            label="Mark all unread"
            onClick={() => { try { localStorage.removeItem('fn:read-posts'); } catch {} window.location.reload(); }}
          />
        </TweakSection>
      </TweaksPanel>
    </React.Fragment>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<SiteApp />);
