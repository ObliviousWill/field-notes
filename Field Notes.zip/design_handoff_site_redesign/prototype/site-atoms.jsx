// site-atoms.jsx — shared header, footer and primitives used across
// every page of the redesign. Builds on the tokens & atoms defined in
// blog-variations.jsx (POSTS, TOKENS, CAT, CategoryChip, UnreadDot,
// FNLink, fmtDate, fmtShortDate, useUnreadState).

// Site-wide nav header with active-page indicator.
function FNHeader({ current = 'blog', mobile = false }) {
  const NAV = [
    { id: 'home', label: 'Home' },
    { id: 'blog', label: 'Blog' },
    { id: 'projects', label: 'Projects' },
    { id: 'about', label: 'About' },
  ];

  return (
    <header style={{
      borderBottom: `1px solid ${TOKENS.hairline}`,
      padding: mobile ? '14px 20px' : '18px 40px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      background: TOKENS.bgSoft,
    }}>
      <a href="#" onClick={(e) => e.preventDefault()} style={{
        fontFamily: 'var(--font-display)',
        color: TOKENS.accent,
        fontSize: mobile ? 18 : 20,
        letterSpacing: '0.02em',
        lineHeight: 1,
        textDecoration: 'none',
      }}>FIELD NOTES</a>

      {!mobile && (
        <nav style={{ display: 'flex', gap: 36 }}>
          {NAV.map((n) => (
            <a key={n.id} href="#" onClick={(e) => e.preventDefault()} style={{
              color: TOKENS.ink,
              textDecoration: 'none',
              fontSize: 17,
              fontFamily: 'var(--font-atkinson)',
              padding: '6px 2px',
              position: 'relative',
              fontWeight: current === n.id ? 700 : 400,
              borderBottom: current === n.id ? `2px solid ${TOKENS.accent}` : '2px solid transparent',
            }}>{n.label}</a>
          ))}
        </nav>
      )}

      <div style={{
        width: mobile ? 26 : 22,
        height: mobile ? 26 : 22,
        background: '#4b5b73',
        color: TOKENS.bgSoft,
        fontSize: mobile ? 13 : 11,
        fontWeight: 700,
        fontFamily: 'var(--font-atkinson)',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 3,
        cursor: 'pointer',
      }}>{mobile ? '≡' : 'in'}</div>
    </header>
  );
}

function FNFooter({ mobile = false }) {
  return (
    <footer style={{
      padding: mobile ? '28px 20px 36px' : '40px 40px 48px',
      textAlign: 'center',
      color: TOKENS.muted,
      fontSize: 15,
      fontFamily: 'var(--font-atkinson)',
      background: TOKENS.bgTint,
      borderTop: `1px solid ${TOKENS.hairline}`,
    }}>
      <div style={{ marginBottom: 14 }}>© 2026 Will. All rights reserved.</div>
      <div style={{
        width: 22, height: 22, background: '#4b5b73', color: TOKENS.bgSoft,
        fontSize: 11, fontWeight: 700, borderRadius: 3,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      }}>in</div>
    </footer>
  );
}

// Status pill — exact match for the existing .status-* CSS classes.
function StatusPill({ status }) {
  const styles = {
    building: { background: TOKENS.accent, color: TOKENS.ink },
    shipped: { background: 'rgba(44, 59, 77, 0.10)', color: TOKENS.ink },
    paused: { background: 'transparent', color: TOKENS.muted, border: `1px solid rgba(44, 59, 77, 0.20)` },
  };
  return (
    <span style={{
      display: 'inline-block',
      padding: '0.15em 0.6em',
      borderRadius: 999,
      fontSize: 12,
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '0.06em',
      whiteSpace: 'nowrap',
      fontFamily: 'var(--font-atkinson)',
      ...styles[status],
    }}>{status}</span>
  );
}

// Page-level title block used on Blog, Projects, About.
function PageTitle({ title, count, countLabel, subtitle, sideLink, mobile = false }) {
  return (
    <React.Fragment>
      <div style={{
        display: 'flex',
        alignItems: 'baseline',
        justifyContent: 'space-between',
        marginBottom: 8,
        flexWrap: 'wrap',
        gap: 12,
      }}>
        <h1 style={{
          fontFamily: 'var(--font-display)',
          fontSize: mobile ? 44 : 64,
          margin: 0,
          lineHeight: 1,
          color: TOKENS.ink,
        }}>{title}</h1>
        {(count != null || sideLink) && (
          <div style={{
            display: 'flex', gap: 12, alignItems: 'center',
            fontSize: 13, color: TOKENS.muted,
          }}>
            {count != null && (
              <span style={{ letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                {count} {countLabel}
              </span>
            )}
            {count != null && sideLink && <span style={{ opacity: 0.4 }}>·</span>}
            {sideLink}
          </div>
        )}
      </div>
      {subtitle && (
        <p style={{
          color: TOKENS.muted,
          fontSize: mobile ? 17 : 19,
          margin: '0 0 8px',
          maxWidth: 620,
          lineHeight: 1.5,
        }}>{subtitle}</p>
      )}
    </React.Fragment>
  );
}

function SectionHeading({ title, sideLink, mobile = false, top = true }) {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      gap: 12,
      flexWrap: 'wrap',
      marginTop: top ? (mobile ? 36 : 56) : 0,
      marginBottom: mobile ? 14 : 20,
    }}>
      <h2 style={{
        fontFamily: 'var(--font-display)',
        fontSize: mobile ? 24 : 30,
        margin: 0,
        color: TOKENS.ink,
        lineHeight: 1,
      }}>{title}</h2>
      {sideLink}
    </div>
  );
}

function HRule({ mobile = false, soft = false }) {
  return <hr style={{
    border: 'none',
    borderTop: `1px solid ${soft ? TOKENS.hairlineSoft : TOKENS.hairline}`,
    margin: mobile ? '24px 0' : '36px 0',
  }} />;
}

// Newsletter block — single canonical visual, used across pages.
function NewsletterBlock({ mobile = false }) {
  return (
    <section style={{
      marginTop: mobile ? 36 : 56,
      paddingTop: mobile ? 28 : 36,
      borderTop: `1px solid ${TOKENS.hairline}`,
    }}>
      <div style={{
        fontFamily: 'var(--font-display)',
        fontSize: mobile ? 28 : 34,
        color: TOKENS.ink,
        marginBottom: 8,
        lineHeight: 1.1,
      }}>Get these in your inbox.</div>
      <p style={{ color: TOKENS.muted, fontSize: mobile ? 16 : 17, margin: '0 0 18px', maxWidth: 520 }}>
        Roughly weekly. No schedule, no spam — just a heads-up when a new note goes up.
      </p>
      <form onSubmit={(e) => e.preventDefault()} style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
        <input type="email" placeholder="you@email.com" style={{
          flex: '1 1 220px',
          minWidth: 200,
          padding: '12px 14px',
          border: `1px solid ${TOKENS.hairline}`,
          background: TOKENS.bgSoft,
          color: TOKENS.ink,
          fontSize: 16,
          borderRadius: 4,
          fontFamily: 'var(--font-atkinson)',
          outline: 'none',
        }} />
        <button type="submit" style={{
          padding: '12px 18px',
          background: TOKENS.ink,
          color: TOKENS.bgSoft,
          border: 'none',
          fontSize: 15,
          fontWeight: 700,
          borderRadius: 4,
          cursor: 'pointer',
          fontFamily: 'var(--font-atkinson)',
        }}>Subscribe →</button>
        <a href="#" onClick={(e) => e.preventDefault()} style={{
          color: TOKENS.muted, fontSize: 14, textDecoration: 'none',
          marginLeft: mobile ? 0 : 8, fontFamily: 'var(--font-atkinson)',
        }}>or grab the <span style={{ color: TOKENS.accentInk, textDecoration: 'underline', textDecorationColor: TOKENS.accent, textDecorationThickness: 2 }}>RSS feed ↗</span></a>
      </form>
    </section>
  );
}

// Compact post row — used on the Home page "Recent posts" list and
// on the post-detail "more notes" footer. Mirrors V1's blog row vocabulary
// (chip + meta + chunky title + excerpt + mentions) at a slightly lighter weight.
function PostRow({ post, unread, onToggle, mobile = false, showExcerpt = true, compact = false, colored = true }) {
  const [hover, setHover] = React.useState(false);
  const titleSize = compact
    ? (mobile ? 20 : 22)
    : (mobile ? 22 : 28);

  return (
    <li
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        position: 'relative',
        padding: `${compact ? (mobile ? 18 : 22) : (mobile ? 26 : 32)}px 0`,
        borderTop: `1px solid ${TOKENS.hairlineSoft}`,
        listStyle: 'none',
      }}
    >
      <div style={{
        position: 'absolute',
        inset: `0 -${mobile ? 12 : 24}px 0 -${mobile ? 12 : 24}px`,
        background: TOKENS.bgSoft,
        opacity: hover ? 0.7 : 0,
        transition: 'opacity 200ms ease',
        borderRadius: 6,
        pointerEvents: 'none',
        zIndex: 0,
      }} />

      <div style={{ position: 'relative', zIndex: 1, display: 'grid', gridTemplateColumns: '24px 1fr', gap: mobile ? 10 : 14, alignItems: 'start' }}>
        <UnreadDot unread={unread} onClick={onToggle} />

        <div>
          <div style={{
            display: 'flex',
            gap: 10,
            alignItems: 'center',
            flexWrap: 'wrap',
            fontSize: 13,
            color: TOKENS.muted,
            marginBottom: 8,
            fontFamily: 'var(--font-atkinson)',
          }}>
            {post.tags && post.tags.map((tag) => (
              <CategoryChip key={tag} tag={tag} colored={colored} />
            ))}
            <span style={{ opacity: 0.4 }}>·</span>
            <span>{fmtDate(post.date)}</span>
            <span style={{ opacity: 0.4 }}>·</span>
            <span>{post.readTime} min read</span>
            {post.updatedDate && (
              <React.Fragment>
                <span style={{ opacity: 0.4 }}>·</span>
                <span style={{
                  display: 'inline-flex', alignItems: 'center', gap: 4,
                  color: TOKENS.accentInk,
                }} title={`Updated ${fmtDate(post.updatedDate)}`}>
                  <span style={{ fontSize: 11 }}>↻</span>
                  <span style={{ fontSize: 12 }}>updated</span>
                </span>
              </React.Fragment>
            )}
          </div>

          <a href="#" onClick={(e) => { e.preventDefault(); onToggle && onToggle(); }}
            style={{
              display: 'inline-block',
              fontFamily: 'var(--font-display)',
              fontSize: titleSize,
              lineHeight: 1.12,
              color: TOKENS.ink,
              textDecoration: 'none',
              marginBottom: 10,
              backgroundImage: `linear-gradient(${TOKENS.accent}, ${TOKENS.accent})`,
              backgroundPosition: '0 100%',
              backgroundRepeat: 'no-repeat',
              backgroundSize: hover ? '100% 6px' : '0 6px',
              transition: 'background-size 280ms cubic-bezier(.6,0,.2,1)',
              paddingBottom: 2,
              boxDecorationBreak: 'clone',
              WebkitBoxDecorationBreak: 'clone',
            }}>{post.title}</a>

          {showExcerpt && post.description && (
            <p style={{
              color: TOKENS.muted,
              margin: '4px 0 0',
              fontSize: mobile ? 16 : 17,
              lineHeight: 1.55,
              maxWidth: 620,
            }}>{post.description}</p>
          )}

          {post.mentions && post.mentions.length > 0 && (
            <div style={{
              marginTop: 12,
              fontSize: 13,
              color: TOKENS.muted,
              fontFamily: 'var(--font-atkinson)',
              display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap',
            }}>
              <span style={{ letterSpacing: '0.06em', textTransform: 'uppercase', fontSize: 11 }}>Mentions</span>
              {post.mentions.map((m, i) => (
                <React.Fragment key={m.slug}>
                  {i > 0 && <span style={{ opacity: 0.4 }}>·</span>}
                  <FNLink style={{ fontSize: 13 }}>↗ {m.label}</FNLink>
                </React.Fragment>
              ))}
            </div>
          )}
        </div>
      </div>
    </li>
  );
}

// Project data — real + plausible placeholders so the Projects page reads.
const PROJECTS = [
  {
    slug: 'field-notes',
    title: 'Field Notes (this site)',
    summary: "A personal site built in the open with Claude Code as the only collaborator. The brief: see how far a non-developer can take a website end to end, and show the work as I go.",
    status: 'building',
    startDate: '2026-05-20',
    lastUpdate: '2026-05-20',
    latestUpdateTitle: 'Foundation in place',
    updateCount: 1,
    real: true,
  },
  {
    slug: 'meal-planner',
    title: 'Meal planner',
    summary: "A weekly meal-planning app on the Claude API. Started as a personal tool; tracking what survives contact with real Tuesday-night use.",
    status: 'building',
    startDate: '2026-04-12',
    lastUpdate: '2026-05-08',
    latestUpdateTitle: 'Switched to per-week prompt context',
    updateCount: 3,
  },
  {
    slug: 'customer-chatbot',
    title: 'AI support chatbot (customer-facing)',
    summary: "An AI chatbot for our customer-facing site at work. Notes here when I can — the post-mortems, the bits I'd do differently.",
    status: 'paused',
    startDate: '2026-02-01',
    lastUpdate: '2026-03-18',
    latestUpdateTitle: 'Paused while we redo the knowledge base',
    updateCount: 2,
  },
];

// ProjectCard — reused on Home and Projects index.
function ProjectCard({ project, mobile = false, expanded = false }) {
  const [hover, setHover] = React.useState(false);
  return (
    <article
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        position: 'relative',
        background: TOKENS.bgSoft,
        border: `1px solid ${TOKENS.hairlineSoft}`,
        borderRadius: 8,
        padding: mobile ? 20 : 28,
        transition: 'border-color 200ms ease, transform 220ms cubic-bezier(.6,0,.2,1)',
        borderColor: hover ? `rgba(255, 177, 98, 0.7)` : TOKENS.hairlineSoft,
      }}
    >
      <header style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 12,
        flexWrap: 'wrap',
        marginBottom: mobile ? 12 : 14,
      }}>
        <div style={{
          fontSize: 11,
          letterSpacing: '0.16em',
          textTransform: 'uppercase',
          color: TOKENS.muted,
          fontFamily: 'var(--font-atkinson)',
        }}>Project</div>
        <StatusPill status={project.status} />
      </header>

      <a href="#" onClick={(e) => e.preventDefault()} style={{
        display: 'inline-block',
        fontFamily: 'var(--font-display)',
        fontSize: mobile ? 24 : 30,
        lineHeight: 1.1,
        color: TOKENS.ink,
        textDecoration: 'none',
        margin: '0 0 12px',
        backgroundImage: `linear-gradient(${TOKENS.accent}, ${TOKENS.accent})`,
        backgroundPosition: '0 100%',
        backgroundRepeat: 'no-repeat',
        backgroundSize: hover ? '100% 6px' : '0 6px',
        transition: 'background-size 280ms cubic-bezier(.6,0,.2,1)',
        paddingBottom: 2,
        boxDecorationBreak: 'clone',
        WebkitBoxDecorationBreak: 'clone',
      }}>{project.title}</a>

      <p style={{
        color: TOKENS.muted,
        fontSize: mobile ? 16 : 17,
        margin: '0 0 16px',
        lineHeight: 1.55,
      }}>{project.summary}</p>

      <div style={{
        display: 'flex', alignItems: 'center', flexWrap: 'wrap',
        gap: 10, fontSize: 13, color: TOKENS.muted, fontFamily: 'var(--font-atkinson)',
        paddingTop: 14, borderTop: `1px dashed ${TOKENS.hairlineSoft}`,
      }}>
        <span style={{ letterSpacing: '0.06em', textTransform: 'uppercase', fontSize: 11 }}>Latest</span>
        <FNLink style={{ fontSize: 13 }}>{project.latestUpdateTitle}</FNLink>
        <span style={{ opacity: 0.4 }}>·</span>
        <span>{fmtDate(project.lastUpdate)}</span>
        {expanded && (
          <React.Fragment>
            <span style={{ flex: 1 }} />
            <span style={{
              fontSize: 11, letterSpacing: '0.06em', textTransform: 'uppercase',
            }}>{project.updateCount} {project.updateCount === 1 ? 'update' : 'updates'}</span>
          </React.Fragment>
        )}
      </div>
    </article>
  );
}

Object.assign(window, {
  FNHeader, FNFooter, StatusPill,
  PageTitle, SectionHeading, HRule, NewsletterBlock,
  PostRow, ProjectCard, PROJECTS,
});
